import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AuthForm } from "@/components/site/AuthForm";
import { SiteNav } from "@/components/site/SiteNav";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in — FLARE Studio" },
      { name: "description", content: "Log in to your FLARE Studio account." },
      { property: "og:title", content: "Log in — FLARE Studio" },
      { property: "og:description", content: "Log in to your FLARE Studio account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

function Page() {
  const navigate = useNavigate();
  return (
    <main className="flex min-h-screen items-center justify-center bg-secondary px-4">
      <SiteNav />
      <AuthForm mode="login" onDone={() => navigate({ to: "/account" })} />
    </main>
  );
}
