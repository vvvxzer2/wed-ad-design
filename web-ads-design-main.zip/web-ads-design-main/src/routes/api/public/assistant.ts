import { createFileRoute } from "@tanstack/react-router";

// Public on purpose: anonymous website visitors chat with the AI strategist.
// The handler validates the visitor id and input and never returns other visitors' data.
export const Route = createFileRoute("/api/public/assistant")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { handleAssistantRequest } = await import("@/lib/ai/assistant.server");
        return handleAssistantRequest(request);
      },
    },
  },
});
