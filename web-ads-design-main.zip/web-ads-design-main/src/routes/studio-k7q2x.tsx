import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AuthForm } from "@/components/site/AuthForm";
import { Button } from "@/components/ui/button";
import { PageEditor } from "@/components/admin/PageEditor";
import { LogPanel, MediaPanel, type MediaRow, SubmissionsPanel, UsersPanel } from "@/components/admin/AdminPanels";
import { DeliverablesPanel } from "@/components/admin/DeliverablesPanel";
import { LiveChatTab } from "@/components/admin/tabs/LiveChatTab";
import { logActivity } from "@/lib/log";
import { cn } from "@/lib/utils";

// Hidden admin studio: never linked from the site and excluded from search engines.
export const Route = createFileRoute("/studio-k7q2x")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Studio" },
      { name: "description", content: "Private studio." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Studio" },
      { property: "og:description", content: "Private studio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Studio,
});

const TABS = ["Page editor", "Live chat", "Media", "Deliverables", "Submissions", "Accounts", "Activity log"] as const;

function Studio() {
  const { user, isAdmin, loading } = useAuth();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Page editor");
  const [media, setMedia] = useState<MediaRow[]>([]);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const reload = useCallback(() => { supabase.from("media").select("*").order("created_at", { ascending: false }).then(({ data }) => setMedia(data ?? [])); }, []);
  const [chatAlerts, setChatAlerts] = useState(0);
  useEffect(() => { if (isAdmin) reload(); }, [isAdmin, reload]);

  // While an admin has the Studio open, visitors see "Team online now" in the chat widget.
  useEffect(() => {
    if (!isAdmin || !user) return;
    const ch = supabase.channel("studio-presence", { config: { presence: { key: user.id } } });
    ch.subscribe((status) => { if (status === "SUBSCRIBED") ch.track({ online_at: new Date().toISOString() }); });
    return () => { supabase.removeChannel(ch); };
  }, [isAdmin, user]);

  async function logout() {
    await logActivity("logout", "Studio");
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
  }

  if (loading) return <div className="min-h-screen bg-secondary" />;
  if (!user) return <main className="flex min-h-screen items-center justify-center bg-secondary px-4"><AuthForm mode="login" title="Studio sign in" hideLinks /></main>;
  if (!isAdmin) return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-secondary text-secondary-foreground">
      <p>This account has no studio access.</p>
      <div className="flex gap-2"><Button onClick={logout}>Log out</Button><Button variant="outline" onClick={() => navigate({ to: "/" })}>Go to site</Button></div>
    </main>
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="flex h-[57px] items-center justify-between border-b bg-secondary px-4 text-secondary-foreground">
        <div className="flex items-center gap-6">
          <span className="font-display text-lg font-extrabold text-primary">FLARE Studio</span>
          <nav className="flex gap-1">
            {TABS.map((t) => (
              <button key={t} onClick={() => setTab(t)} className={cn("relative rounded-md px-3 py-1.5 text-sm", tab === t ? "bg-primary text-primary-foreground" : "hover:bg-sidebar-accent")}>
                {t}
                {t === "Live chat" && chatAlerts > 0 && <span className={cn("ml-1.5 rounded-full px-1.5 text-[10px] font-bold", tab === t ? "bg-secondary text-secondary-foreground" : "bg-primary text-primary-foreground")}>{chatAlerts}</span>}
              </button>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <a href="/" target="_blank" rel="noreferrer" className="underline">View site</a>
          <span className="opacity-60">{user.email}</span>
          <Button size="sm" variant="outline" className="text-foreground" onClick={logout}>Log out</Button>
        </div>
      </header>
      {tab === "Page editor" && <PageEditor media={media} />}
      <div className={tab === "Live chat" ? "" : "hidden"}><LiveChatTab meId={user.id} onUnreadChange={setChatAlerts} /></div>
      {tab === "Media" && <MediaPanel media={media} reload={reload} />}
      {tab === "Deliverables" && <DeliverablesPanel meId={user.id} />}
      {tab === "Submissions" && <SubmissionsPanel />}
      {tab === "Accounts" && <UsersPanel meId={user.id} />}
      {tab === "Activity log" && <LogPanel />}
    </div>
  );
}
