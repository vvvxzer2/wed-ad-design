import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AccountTabs } from "@/components/account/AccountTabs";
import { MemberMessages } from "@/components/account/MemberMessages";
import { SiteNav } from "@/components/site/SiteNav";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/account/messages")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Messages — FLARE Studio" },
      { name: "description", content: "Private one-to-one messages with the FLARE team and other members, with read receipts and image sharing." },
      { property: "og:title", content: "Messages — FLARE Studio" },
      { property: "og:description", content: "Private one-to-one messages with the FLARE team and other members, with read receipts and image sharing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MessagesPage,
});

function MessagesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && !user) navigate({ to: "/login", replace: true }); }, [user, loading, navigate]);
  if (!user) return null;
  return (
    <main className="min-h-screen bg-background pb-10">
      <div className="relative h-24 bg-secondary"><SiteNav /></div>
      <AccountTabs />
      <div className="px-4 md:px-6">
        <h1 className="mx-auto mt-6 max-w-6xl text-3xl font-bold">Messages</h1>
        <MemberMessages meId={user.id} />
      </div>
    </main>
  );
}
