import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AccountTabs } from "@/components/account/AccountTabs";
import { DeliverablesVault } from "@/components/account/DeliverablesVault";
import { SiteNav } from "@/components/site/SiteNav";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/account/deliverables")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Deliverables — FLARE Studio" },
      { name: "description", content: "Browse and download the ad creatives, video cuts and files FLARE has delivered for your campaigns." },
      { property: "og:title", content: "Deliverables — FLARE Studio" },
      { property: "og:description", content: "Browse and download the ad creatives, video cuts and files FLARE has delivered for your campaigns." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DeliverablesPage,
});

function DeliverablesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && !user) navigate({ to: "/login", replace: true }); }, [user, loading, navigate]);
  if (!user) return null;
  return (
    <main className="min-h-screen bg-background pb-16">
      <div className="relative h-24 bg-secondary"><SiteNav /></div>
      <AccountTabs />
      <DeliverablesVault meId={user.id} />
    </main>
  );
}
