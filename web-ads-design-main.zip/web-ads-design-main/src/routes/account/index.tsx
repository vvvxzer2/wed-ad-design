import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { SiteNav } from "@/components/site/SiteNav";
import { AccountTabs } from "@/components/account/AccountTabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { logActivity } from "@/lib/log";
import { MEDIA_BUCKET, useMediaUrl } from "@/lib/media";
import { deleteAccount } from "@/lib/users.functions";

export const Route = createFileRoute("/account/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "My account — FLARE Studio" },
      { name: "description", content: "Manage your FLARE Studio profile, password and activity." },
      { property: "og:title", content: "My account — FLARE Studio" },
      { property: "og:description", content: "Manage your FLARE Studio profile, password and activity." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Account,
});

type Log = { id: string; action: string; details: string | null; created_at: string };

function Account() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<string | undefined>();
  const [pw, setPw] = useState("");
  const [logs, setLogs] = useState<Log[]>([]);
  const avatarUrl = useMediaUrl(avatar);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/login", replace: true });
    if (!user) return;
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => {
      setName(data?.display_name ?? ""); setBio(data?.bio ?? ""); setAvatar(data?.avatar_url ?? undefined);
    });
    supabase.from("activity_log").select("id,action,details,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20).then(({ data }) => setLogs(data ?? []));
  }, [user, loading, navigate]);

  if (!user) return null;

  async function save() {
    const { error } = await supabase.from("profiles").update({ display_name: name, bio, avatar_url: avatar ?? null, updated_at: new Date().toISOString() }).eq("id", user!.id);
    if (error) { toast.error(error.message); return; }
    await logActivity("profile_update");
    toast.success("Profile saved");
  }
  async function uploadAvatar(f: File) {
    const path = `avatars/${user!.id}/${Date.now()}-${f.name.replace(/[^\w.-]/g, "_")}`;
    const { error } = await supabase.storage.from(MEDIA_BUCKET).upload(path, f);
    if (error) { toast.error(error.message); return; }
    setAvatar(path);
  }
  async function changePw() {
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) { toast.error(error.message); return; }
    setPw(""); await logActivity("password_change"); toast.success("Password updated");
  }
  async function logout() {
    await logActivity("logout");
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }
  async function remove() {
    if (!confirm("Delete your account permanently?")) return;
    try { await deleteAccount({ data: { userId: user!.id } }); await supabase.auth.signOut(); navigate({ to: "/", replace: true }); }
    catch (e) { toast.error((e as Error).message); }
  }

  return (
    <main className="min-h-screen bg-background pb-20">
      <div className="relative h-24 bg-secondary"><SiteNav /></div>
      <AccountTabs />
      <div className="mx-auto mt-10 grid max-w-4xl gap-8 px-6 md:grid-cols-[1fr_1fr]">
        <section className="rounded-xl border bg-card p-6">
          <h1 className="text-2xl font-bold">Profile</h1>
          <div className="mt-5 flex items-center gap-4">
            <div className="size-16 overflow-hidden rounded-full bg-muted">{avatarUrl && <img src={avatarUrl} alt="" className="size-full object-cover" />}</div>
            <label className="cursor-pointer text-sm font-semibold underline">Change photo<input type="file" accept="image/*" hidden onChange={(e) => e.target.files?.[0] && uploadAvatar(e.target.files[0])} /></label>
          </div>
          <div className="mt-4 grid gap-3">
            <div className="grid gap-1.5"><Label>Email</Label><Input value={user.email ?? ""} disabled /></div>
            <div className="grid gap-1.5"><Label>Display name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
            <div className="grid gap-1.5"><Label>Bio</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value)} /></div>
            <Button onClick={save}>Save profile</Button>
          </div>
        </section>
        <div className="grid content-start gap-8">
          <section className="rounded-xl border bg-card p-6">
            <h2 className="text-xl font-bold">Password</h2>
            <div className="mt-4 flex gap-2"><Input type="password" placeholder="New password" minLength={6} value={pw} onChange={(e) => setPw(e.target.value)} /><Button onClick={changePw} disabled={pw.length < 6}>Update</Button></div>
          </section>
          <section className="rounded-xl border bg-card p-6">
            <h2 className="text-xl font-bold">Recent activity</h2>
            <ul className="mt-3 grid gap-1 text-sm">
              {logs.map((l) => <li key={l.id} className="flex justify-between gap-2 text-muted-foreground"><span className="text-foreground">{l.action.replace("_", " ")}</span><span>{new Date(l.created_at).toLocaleString()}</span></li>)}
              {!logs.length && <li className="text-muted-foreground">No activity yet.</li>}
            </ul>
          </section>
          <div className="flex gap-3"><Button variant="secondary" onClick={logout}>Log out</Button><Button variant="destructive" onClick={remove}>Delete account</Button></div>
        </div>
      </div>
    </main>
  );
}
