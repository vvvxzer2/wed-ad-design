import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { BlockView } from "@/components/site/BlockRenderer";
import { SiteNav } from "@/components/site/SiteNav";
import { VisitorChat } from "@/components/chat/VisitorChat";
import { pageQuery } from "@/lib/pages";
import { checkDatabaseSetup } from "@/lib/schema-check.functions";
import { SetupIncomplete } from "@/components/site/SetupIncomplete";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FLARE — Ads & Marketing Studio" },
      { name: "description", content: "Campaigns, motion and media that move people and metrics." },
      { property: "og:title", content: "FLARE — Ads & Marketing Studio" },
      { property: "og:description", content: "Campaigns, motion and media that move people and metrics." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  // Startup check: confirm the database tables exist before loading page content,
  // so missing migrations show a clear notice instead of a crash.
  loader: async ({ context }) => {
    // If the check itself can't run, fall through to the page; pageQuery has its own fallback.
    const health = await checkDatabaseSetup().catch((e) => {
      console.error("[startup-check] check failed", e);
      return null;
    });
    if (!health?.missingMigrations) await context.queryClient.ensureQueryData(pageQuery("home"));
    return { health };
  },
  component: Index,
});

function Index() {
  // Loader data can be stale or absent (e.g. after a hot reload), so treat it as optional.
  const health = Route.useLoaderData()?.health ?? null;
  if (health?.missingMigrations) return <SetupIncomplete health={health} />;
  return <HomePage />;
}

function HomePage() {
  const { data } = useSuspenseQuery(pageQuery("home"));
  return (
    <main className="relative">
      <SiteNav />
      {data.blocks.map((b) => <BlockView key={b.id} block={b} slug="home" />)}
      {!data.blocks.length && (
        <section className="flex min-h-[70vh] flex-col items-center justify-center gap-3 bg-gradient-flame px-6 text-center text-secondary-foreground">
          <h1 className="font-display text-4xl font-extrabold md:text-6xl">FLARE — Ads &amp; Marketing Studio</h1>
          <p className="max-w-md opacity-80">{data.unavailable ? "We're updating the site — please check back in a moment." : "Ads that refuse to be ignored."}</p>
        </section>
      )}
      <VisitorChat />
      <footer className="bg-secondary px-6 py-10 text-center text-sm text-secondary-foreground/70">© {new Date().getFullYear()} FLARE Studio</footer>
    </main>
  );
}
