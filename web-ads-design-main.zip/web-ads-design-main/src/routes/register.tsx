import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AuthForm } from "@/components/site/AuthForm";
import { SiteNav } from "@/components/site/SiteNav";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create an account — FLARE Studio" },
      { name: "description", content: "Create a FLARE Studio account to message the team and download your campaign deliverables." },
      { property: "og:title", content: "Create an account — FLARE Studio" },
      { property: "og:description", content: "Create a FLARE Studio account to message the team and download your campaign deliverables." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

function Page() {
  const navigate = useNavigate();
  return (
    <main className="flex min-h-screen items-center justify-center bg-secondary px-4">
      <SiteNav />
      <AuthForm mode="register" title="Create a FLARE Studio account" onDone={() => navigate({ to: "/account" })} />
    </main>
  );
}
