import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/** Unread member-to-member messages for the signed-in user, kept live via Realtime. */
export function useUnreadMessages(userId: string | undefined) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!userId) { setCount(0); return; }
    let active = true;
    const load = () => supabase.rpc("my_unread_total").then(({ data }) => active && setCount(Number(data ?? 0)));
    load();
    const ch = supabase
      .channel(`unread-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, load)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "thread_participants", filter: `user_id=eq.${userId}` }, load)
      .subscribe();
    window.addEventListener("focus", load);
    return () => { active = false; supabase.removeChannel(ch); window.removeEventListener("focus", load); };
  }, [userId]);
  return count;
}
