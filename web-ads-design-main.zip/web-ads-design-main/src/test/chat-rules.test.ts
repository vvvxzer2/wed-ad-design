import { describe, expect, it } from "vitest";
import { isUuid, nearestAspect, wantsHuman } from "@/lib/chat-shared";

describe("AI hand-over to a human", () => {
  it("escalates when the visitor types agent/human", () => {
    expect(wantsHuman("can I talk to a human?")).toBe(true);
    expect(wantsHuman("agent please")).toBe(true);
    expect(wantsHuman("I want a real person")).toBe(true);
  });
  it("does not escalate ordinary marketing questions", () => {
    expect(wantsHuman("What ad formats do you deliver for Reels?")).toBe(false);
    expect(wantsHuman("Our audience is humanities students")).toBe(false);
  });
});

describe("deliverable aspect ratios", () => {
  it("maps standard ad sizes to their patterns", () => {
    expect(nearestAspect(1080, 1080)).toBe("1:1");
    expect(nearestAspect(1080, 1920)).toBe("9:16");
    expect(nearestAspect(1920, 1080)).toBe("16:9");
    expect(nearestAspect(1080, 1350)).toBe("4:5");
  });
  it("marks unusual sizes as other", () => {
    expect(nearestAspect(1000, 300)).toBe("other");
    expect(nearestAspect(0, 0)).toBe("other");
  });
});

describe("visitor ids", () => {
  it("only accepts real UUIDs", () => {
    expect(isUuid("93286364-bb7d-4519-80b7-478705a7e08c")).toBe(true);
    expect(isUuid("nope")).toBe(false);
  });
});
