import { describe, expect, it } from "vitest";
import { AGENCY_KNOWLEDGE, ASSISTANT_INSTRUCTIONS } from "@/lib/assistant-knowledge";

describe("AI strategist pricing", () => {
  it("quotes in Swedish kronor, never dollars", () => {
    expect(AGENCY_KNOWLEDGE).not.toContain("$");
    expect(ASSISTANT_INSTRUCTIONS).toContain("Swedish kronor");
  });
  it("lists the creative sprint from 25 000 kr", () => {
    expect(AGENCY_KNOWLEDGE).toContain("from 25 000 kr");
  });
  it("lists paid-media management from 15 000 kr/month or 12% above 150 000 kr", () => {
    expect(AGENCY_KNOWLEDGE).toContain("from 15 000 kr/month, or 12% of ad spend above 150 000 kr/month");
  });
  it("lists UGC videos from 3 500 kr each, min. 4", () => {
    expect(AGENCY_KNOWLEDGE).toContain("from 3 500 kr per finished video (min. 4 videos)");
  });
  it("lists landing pages from 30 000 kr and motion graphics from 6 000 kr", () => {
    expect(AGENCY_KNOWLEDGE).toContain("Landing page design & build: from 30 000 kr");
    expect(AGENCY_KNOWLEDGE).toContain("Motion graphics: from 6 000 kr per animated asset");
  });
  it("states prices exclude VAT", () => {
    expect(AGENCY_KNOWLEDGE).toContain("excl. 25% VAT");
  });
});
