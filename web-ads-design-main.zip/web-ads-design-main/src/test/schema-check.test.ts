import { describe, expect, it } from "vitest";
import { allRequiredTables, isMissingTableError, summarizeSchema } from "@/lib/schema-check";

describe("startup database check", () => {
  it("treats 'table not in schema cache' as a missing table", () => {
    expect(isMissingTableError("PGRST205", "Could not find the table 'public.pages' in the schema cache")).toBe(true);
    expect(isMissingTableError("42P01", null)).toBe(true);
    expect(isMissingTableError("42501", "permission denied for table pages")).toBe(false);
  });

  it("names the migration that creates each missing table", () => {
    const results = allRequiredTables().map((table) => ({
      table,
      status: table === "pages" || table === "chat_messages" ? ("missing" as const) : ("ok" as const),
    }));
    const h = summarizeSchema(results);
    expect(h.ok).toBe(false);
    expect(h.missingTables).toEqual(["pages", "chat_messages"]);
    expect(h.pendingMigrations).toEqual(["0000_flare_core_schema", "0001_chat_dm_deliverables"]);
  });

  it("does not report missing migrations when only the network fails", () => {
    const h = summarizeSchema(allRequiredTables().map((table) => ({ table, status: "error" as const })));
    expect(h.missingMigrations).toBe(false);
    expect(h.pendingMigrations).toEqual([]);
  });

  it("is healthy when every table answers", () => {
    expect(summarizeSchema(allRequiredTables().map((table) => ({ table, status: "ok" as const }))).ok).toBe(true);
  });
});
