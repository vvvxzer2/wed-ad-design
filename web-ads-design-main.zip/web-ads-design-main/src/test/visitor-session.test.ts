import { beforeAll, describe, expect, it } from "vitest";
import { sanitizeVisitorMeta, visitorIdFromToken } from "@/lib/chat-shared";

beforeAll(() => {
  process.env["VISITOR_TOKEN_SECRET"] = "test-secret-for-visitor-sessions-0123456789";
});

describe("visitor chat sessions", () => {
  it("accepts tokens the server issued", async () => {
    const { mintVisitorToken, requireVisitor } = await import("@/lib/visitor-chat.server");
    const { token, visitorId } = await mintVisitorToken();
    expect(visitorIdFromToken(token)).toBe(visitorId);
    await expect(requireVisitor(token)).resolves.toBe(visitorId);
  });

  it("rejects a caller-chosen visitor id or a tampered token", async () => {
    const { mintVisitorToken, requireVisitor } = await import("@/lib/visitor-chat.server");
    const { token } = await mintVisitorToken();
    const [, , sig] = token.split(".");
    await expect(requireVisitor("11111111-1111-4111-8111-111111111111")).rejects.toThrow("VISITOR_SESSION_INVALID");
    await expect(requireVisitor(`v1.11111111-1111-4111-8111-111111111111.${sig}`)).rejects.toThrow("VISITOR_SESSION_INVALID");
    await expect(requireVisitor(`${token.slice(0, -2)}xx`)).rejects.toThrow("VISITOR_SESSION_INVALID");
  });

  it("drops unknown visitor details so callers can't overwrite internal fields", () => {
    expect(sanitizeVisitorMeta({ device: "Mobile", ip_hash: "forged", page: "x".repeat(500) })).toEqual({ device: "Mobile", page: "x".repeat(300) });
    expect(sanitizeVisitorMeta("nope")).toBeUndefined();
  });
});
