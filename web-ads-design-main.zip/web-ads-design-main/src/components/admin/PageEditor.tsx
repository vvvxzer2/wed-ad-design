import { useEffect, useState } from "react";
import { DndContext, PointerSensor, closestCenter, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Copy, Monitor, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { BlockView } from "@/components/site/BlockRenderer";
import { Inspector } from "@/components/admin/Inspector";
import { BLOCK_LABELS, type Block, type BlockType, defaultBlock, newId } from "@/lib/blocks";
import { logActivity } from "@/lib/log";
import { cn } from "@/lib/utils";

type Media = { path: string; name: string; kind: string };

function SortableBlock({ block, selected, onSelect, onDuplicate }: { block: Block; selected: boolean; onSelect: () => void; onDuplicate: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: block.id });
  return (
    <div ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition }} className={cn("group relative", isDragging && "z-50 opacity-70")}>
      <div onClickCapture={(e) => { e.preventDefault(); onSelect(); }} className={cn("outline-2 outline-offset-[-2px] transition", selected ? "outline outline-primary" : "hover:outline hover:outline-primary/40")}>
        <BlockView block={block} slug="preview" />
      </div>
      <div className={cn("absolute left-2 top-2 z-10 flex gap-1 opacity-0 transition group-hover:opacity-100", selected && "opacity-100")}>
        <button {...attributes} {...listeners} className="cursor-grab rounded bg-secondary p-1.5 text-secondary-foreground active:cursor-grabbing" aria-label="Drag to move"><GripVertical className="size-4" /></button>
        <span className="rounded bg-secondary px-2 py-1 text-xs font-semibold text-secondary-foreground">{BLOCK_LABELS[block.type]}</span>
        <button onClick={onDuplicate} className="rounded bg-secondary p-1.5 text-secondary-foreground" aria-label="Duplicate"><Copy className="size-4" /></button>
      </div>
    </div>
  );
}

export function PageEditor({ media }: { media: Media[] }) {
  const qc = useQueryClient();
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);
  const [mobile, setMobile] = useState(false);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  useEffect(() => {
    supabase.from("pages").select("blocks").eq("slug", "home").maybeSingle().then(({ data }) => setBlocks(((data?.blocks as unknown) as Block[]) ?? []));
  }, []);

  const update = (next: Block[]) => { setBlocks(next); setDirty(true); };
  const selected = blocks.find((b) => b.id === sel);

  function onDragEnd(e: DragEndEvent) {
    if (!e.over || e.active.id === e.over.id) return;
    const from = blocks.findIndex((b) => b.id === e.active.id);
    const to = blocks.findIndex((b) => b.id === e.over!.id);
    update(arrayMove(blocks, from, to));
  }
  function add(t: BlockType) {
    const b = defaultBlock(t);
    const idx = sel ? blocks.findIndex((x) => x.id === sel) + 1 : blocks.length;
    update([...blocks.slice(0, idx), b, ...blocks.slice(idx)]);
    setSel(b.id);
  }
  async function save() {
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("pages").upsert({ slug: "home", title: "Home", blocks: blocks as never, updated_at: new Date().toISOString(), updated_by: u.user?.id ?? null });
    if (error) { toast.error(error.message); return; }
    setDirty(false);
    qc.invalidateQueries({ queryKey: ["page", "home"] });
    await logActivity("page_publish", `${blocks.length} sections`);
    toast.success("Published to the live site");
  }

  return (
    <div className="grid h-[calc(100vh-57px)] grid-cols-[200px_1fr_320px]">
      <aside className="overflow-y-auto border-r bg-sidebar p-3 text-sidebar-foreground">
        <p className="mb-2 px-1 text-xs font-bold uppercase tracking-wide opacity-60">Add section</p>
        <div className="grid gap-1">
          {(Object.keys(BLOCK_LABELS) as BlockType[]).map((t) => (
            <button key={t} onClick={() => add(t)} className="rounded-md px-3 py-2 text-left text-sm hover:bg-sidebar-accent">+ {BLOCK_LABELS[t]}</button>
          ))}
        </div>
        <p className="mt-6 px-1 text-xs opacity-60">Drag the ⋮⋮ handle on any section to reorder it. Click a section to edit it.</p>
      </aside>

      <div className="flex flex-col overflow-hidden bg-muted">
        <div className="flex items-center justify-between border-b bg-background px-4 py-2">
          <div className="flex gap-1">
            <Button size="sm" variant={mobile ? "ghost" : "secondary"} onClick={() => setMobile(false)}><Monitor className="size-4" /></Button>
            <Button size="sm" variant={mobile ? "secondary" : "ghost"} onClick={() => setMobile(true)}><Smartphone className="size-4" /></Button>
          </div>
          <div className="flex items-center gap-3">
            {dirty && <span className="text-xs text-muted-foreground">Unsaved changes</span>}
            <Button size="sm" onClick={save} disabled={!dirty}>Publish</Button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-6">
          <div className={cn("mx-auto overflow-hidden rounded-lg bg-background shadow-xl transition-all", mobile ? "max-w-[390px]" : "max-w-full")}>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
              <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
                {blocks.map((b) => (
                  <SortableBlock key={b.id} block={b} selected={b.id === sel} onSelect={() => setSel(b.id)}
                    onDuplicate={() => { const i = blocks.indexOf(b); const c = { ...b, id: newId(), props: { ...b.props } }; update([...blocks.slice(0, i + 1), c, ...blocks.slice(i + 1)]); }} />
                ))}
              </SortableContext>
            </DndContext>
            {!blocks.length && <p className="p-20 text-center text-muted-foreground">Empty page — add a section from the left.</p>}
          </div>
        </div>
      </div>

      <aside className="overflow-y-auto border-l bg-card">
        {selected
          ? <Inspector block={selected} media={media} onChange={(p) => update(blocks.map((b) => (b.id === selected.id ? { ...b, props: { ...b.props, ...p } } : b)))} onDelete={() => { update(blocks.filter((b) => b.id !== selected.id)); setSel(null); }} />
          : <p className="p-6 text-sm text-muted-foreground">Select a section on the page to edit its text, buttons, colors, background, motion and light.</p>}
      </aside>
    </div>
  );
}
