import { Trash2, Upload } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { ASPECTS, DELIVERABLES_BUCKET, detectAspect, fileKind, fileTypeLabel, formatBytes, type AspectRatio, type DeliverableRow } from "@/lib/deliverables";
import { logActivity } from "@/lib/log";

type Client = { id: string; email: string | null; display_name: string | null };

export function DeliverablesPanel({ meId }: { meId: string }) {
  const [clients, setClients] = useState<Client[]>([]);
  const [clientId, setClientId] = useState("");
  const [rows, setRows] = useState<DeliverableRow[]>([]);
  const [campaign, setCampaign] = useState("");
  const [tags, setTags] = useState("");
  const [aspect, setAspect] = useState<AspectRatio | "auto">("auto");
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("profiles").select("id,email,display_name").order("display_name").then(({ data }) => setClients(data ?? []));
  }, []);
  const load = (id = clientId) => {
    if (!id) { setRows([]); return; }
    supabase.from("deliverables").select("*").eq("client_id", id).order("created_at", { ascending: false }).then(({ data }) => setRows((data as DeliverableRow[] | null) ?? []));
  };
  useEffect(() => { load(clientId); }, [clientId]);

  async function upload(files: FileList) {
    if (!clientId) { toast.error("Choose a client first"); return; }
    const tagList = tags.split(",").map((t) => t.trim()).filter(Boolean);
    for (const f of Array.from(files)) {
      setBusy(f.name);
      const path = `${clientId}/${Date.now()}-${f.name.replace(/[^\w.-]/g, "_")}`;
      const { error } = await supabase.storage.from(DELIVERABLES_BUCKET).upload(path, f, { contentType: f.type || undefined });
      if (error) { toast.error(`${f.name}: ${error.message}`); continue; }
      const ratio = aspect === "auto" ? await detectAspect(f) : aspect;
      const { error: e2 } = await supabase.from("deliverables").insert({
        client_id: clientId,
        title: f.name.replace(/\.[^.]+$/, ""),
        campaign: campaign.trim() || null,
        tags: tagList,
        aspect_ratio: ratio,
        file_type: fileTypeLabel(f.name),
        kind: fileKind(f),
        path,
        size_bytes: f.size,
        created_by: meId,
      });
      if (e2) toast.error(`${f.name}: ${e2.message}`);
      else await logActivity("deliverable_upload", f.name);
    }
    setBusy(null);
    load();
  }

  async function remove(r: DeliverableRow) {
    if (!confirm(`Delete ${r.title}?`)) return;
    await supabase.storage.from(DELIVERABLES_BUCKET).remove([r.path]);
    await supabase.from("deliverables").delete().eq("id", r.id);
    load();
  }

  async function updateAspect(r: DeliverableRow, value: AspectRatio) {
    await supabase.from("deliverables").update({ aspect_ratio: value }).eq("id", r.id);
    load();
  }

  return (
    <div className="mx-auto max-w-5xl p-8">
      <h1 className="text-3xl font-bold">Client deliverables</h1>
      <p className="mt-1 text-sm text-muted-foreground">Upload finished banners, video cuts and reports for a client. They download them from their account with short-lived secure links.</p>

      <div className="mt-6 grid gap-4 rounded-xl border bg-card p-5 md:grid-cols-2">
        <div className="grid gap-1.5 md:col-span-2">
          <Label htmlFor="client">Client</Label>
          <select id="client" value={clientId} onChange={(e) => setClientId(e.target.value)} className="h-9 rounded-md border bg-background px-3 text-sm">
            <option value="">Choose a client…</option>
            {clients.map((c) => <option key={c.id} value={c.id}>{c.display_name || c.email} {c.email && c.display_name ? `(${c.email})` : ""}</option>)}
          </select>
        </div>
        <div className="grid gap-1.5"><Label htmlFor="camp">Campaign</Label><Input id="camp" placeholder="e.g. Summer Launch 2026" value={campaign} onChange={(e) => setCampaign(e.target.value)} /></div>
        <div className="grid gap-1.5"><Label htmlFor="tags">Tags (comma separated)</Label><Input id="tags" placeholder="meta, ugc, final" value={tags} onChange={(e) => setTags(e.target.value)} /></div>
        <div className="grid gap-1.5">
          <Label htmlFor="aspect">Aspect ratio</Label>
          <select id="aspect" value={aspect} onChange={(e) => setAspect(e.target.value as AspectRatio | "auto")} className="h-9 rounded-md border bg-background px-3 text-sm">
            <option value="auto">Detect automatically</option>
            {ASPECTS.map((a) => <option key={a.value} value={a.value}>{a.label}</option>)}
          </select>
        </div>
        <div className="flex items-end">
          <label className={`inline-flex cursor-pointer items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground ${!clientId ? "pointer-events-none opacity-50" : ""}`}>
            <Upload className="size-4" /> {busy ? `Uploading ${busy}…` : "Upload files"}
            <input type="file" multiple hidden disabled={!clientId || !!busy} onChange={(e) => { if (e.target.files) upload(e.target.files); e.target.value = ""; }} />
          </label>
        </div>
      </div>

      {clientId && (
        <table className="mt-6 w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="py-2">File</th><th>Campaign</th><th>Format</th><th>Size</th><th /></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="py-3"><div className="font-semibold">{r.title}</div><div className="flex gap-1 pt-1">{r.tags.map((t) => <Badge key={t} variant="secondary" className="text-[10px]">{t}</Badge>)}</div></td>
                <td>{r.campaign ?? "—"}</td>
                <td>
                  <span className="mr-2 font-semibold">{r.file_type}</span>
                  <select value={r.aspect_ratio} onChange={(e) => updateAspect(r, e.target.value as AspectRatio)} className="rounded border bg-background px-1 py-0.5 text-xs">
                    {ASPECTS.map((a) => <option key={a.value} value={a.value}>{a.label}</option>)}
                  </select>
                </td>
                <td className="text-muted-foreground">{formatBytes(r.size_bytes)}</td>
                <td className="text-right"><Button size="icon-sm" variant="ghost" onClick={() => remove(r)} aria-label="Delete"><Trash2 className="text-destructive" /></Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {clientId && !rows.length && <p className="mt-6 text-center text-muted-foreground">No deliverables for this client yet.</p>}
    </div>
  );
}
