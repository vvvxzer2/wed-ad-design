import type { ReactNode } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { BLOCK_LABELS, type Block, type BlockProps, isVideo } from "@/lib/blocks";

type Media = { path: string; name: string; kind: string };

const Row = ({ label, children }: { label: string; children: ReactNode }) => (
  <div className="grid gap-1.5"><Label className="text-xs uppercase tracking-wide text-muted-foreground">{label}</Label>{children}</div>
);
const Group = ({ title, children }: { title: string; children: ReactNode }) => (
  <div className="grid gap-3 border-t pt-4"><h4 className="text-sm font-bold">{title}</h4>{children}</div>
);
function Color({ v, on }: { v?: string | undefined; on: (s: string) => void }) {
  return <div className="flex gap-2"><input type="color" value={v ?? "#000000"} onChange={(e) => on(e.target.value)} className="h-9 w-12 cursor-pointer rounded border bg-transparent" /><Input value={v ?? ""} onChange={(e) => on(e.target.value)} /></div>;
}
function Sel<T extends string>({ v, opts, on }: { v?: T | undefined; opts: readonly T[]; on: (s: T) => void }) {
  return <select value={v} onChange={(e) => on(e.target.value as T)} className="h-9 rounded-md border bg-background px-2 text-sm">{opts.map((o) => <option key={o} value={o}>{o}</option>)}</select>;
}
const Toggle = ({ label, v, on }: { label: string; v?: boolean | undefined; on: (b: boolean) => void }) => (
  <label className="flex items-center justify-between text-sm">{label}<Switch checked={!!v} onCheckedChange={on} /></label>
);

export function Inspector({ block, onChange, onDelete, media }: { block: Block; onChange: (p: Partial<BlockProps>) => void; onDelete: () => void; media: Media[] }) {
  const p = block.props;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const set = (k: keyof BlockProps) => (v: any) => onChange({ [k]: v } as Partial<BlockProps>);
  const hasText = block.type !== "spacer";
  const hasBtn = ["hero", "button", "form", "download"].includes(block.type);
  const pickable = block.type === "download" ? media : media.filter((m) => m.kind === "image" || m.kind === "video");

  return (
    <div className="grid gap-4 p-4">
      <div className="flex items-center justify-between"><h3 className="font-display text-lg font-bold">{BLOCK_LABELS[block.type]}</h3><Button size="sm" variant="destructive" onClick={onDelete}>Delete</Button></div>

      <Group title="Content">
        {["hero", "text", "form", "media", "download"].includes(block.type) && <Row label="Heading"><Textarea rows={2} value={p.heading ?? ""} onChange={(e) => set("heading")(e.target.value)} /></Row>}
        {block.type === "hero" && <Row label="Subheading"><Textarea rows={2} value={p.sub ?? ""} onChange={(e) => set("sub")(e.target.value)} /></Row>}
        {block.type === "text" && <Row label="Body"><Textarea rows={5} value={p.body ?? ""} onChange={(e) => set("body")(e.target.value)} /></Row>}
        {block.type === "hero" && <><Row label="Button text"><Input value={p.buttonText ?? ""} onChange={(e) => set("buttonText")(e.target.value)} /></Row><Row label="Button link"><Input value={p.buttonHref ?? ""} onChange={(e) => set("buttonHref")(e.target.value)} /></Row></>}
        {block.type === "button" && <><Row label="Button text"><Input value={p.text ?? ""} onChange={(e) => set("text")(e.target.value)} /></Row><Row label="Link"><Input value={p.href ?? ""} onChange={(e) => set("href")(e.target.value)} /></Row></>}
        {block.type === "form" && <><Row label="Fields (comma separated)"><Input value={p.fields ?? ""} onChange={(e) => set("fields")(e.target.value)} /></Row><Row label="Button text"><Input value={p.buttonText ?? ""} onChange={(e) => set("buttonText")(e.target.value)} /></Row></>}
        {block.type === "media" && <Row label="Display pattern"><Sel v={p.pattern} opts={["single", "grid", "masonry", "strip", "split"] as const} on={set("pattern")} /></Row>}
        {(block.type === "media" || block.type === "download") && (
          <Row label="Files">
            <div className="grid gap-1">
              {(p.items ?? []).map((it) => <div key={it} className="flex items-center justify-between rounded bg-muted px-2 py-1 text-xs"><span className="truncate">{it.split("/").pop()}</span><button onClick={() => set("items")((p.items ?? []).filter((x) => x !== it))}><X className="size-3" /></button></div>)}
              <select value="" onChange={(e) => e.target.value && set("items")([...(p.items ?? []), e.target.value])} className="h-9 rounded-md border bg-background px-2 text-sm">
                <option value="">+ Add from library…</option>
                {pickable.map((m) => <option key={m.path} value={m.path}>{m.name}</option>)}
              </select>
            </div>
          </Row>
        )}
        {block.type === "spacer" && <Row label={`Height: ${p.height}px`}><Slider min={10} max={400} value={[p.height ?? 80]} onValueChange={([v]) => set("height")(v)} /></Row>}
        <Row label="Anchor id (for links like #contact)"><Input value={p.anchor ?? ""} onChange={(e) => set("anchor")(e.target.value)} /></Row>
      </Group>

      {hasText && (
        <Group title="Layout & text">
          <Toggle label="Section padding" v={p.padded} on={set("padded")} />
          <Row label="Align"><Sel v={p.align} opts={["left", "center", "right"] as const} on={set("align")} /></Row>
          <Row label="Heading size"><Sel v={p.size} opts={["sm", "md", "lg", "xl"] as const} on={set("size")} /></Row>
          <Row label="Text color"><Color v={p.textColor} on={set("textColor")} /></Row>
        </Group>
      )}

      {hasBtn && (
        <Group title="Button">
          <Toggle label="Button padding (off = text link)" v={p.btnPadded} on={set("btnPadded")} />
          <Row label="Button color"><Color v={p.btnColor} on={set("btnColor")} /></Row>
          <Row label="Button text color"><Color v={p.btnTextColor} on={set("btnTextColor")} /></Row>
          <Row label={`Corner radius: ${p.radius ?? 8}px`}><Slider min={0} max={40} value={[p.radius ?? 8]} onValueChange={([v]) => set("radius")(v)} /></Row>
        </Group>
      )}

      <Group title="Background">
        <Row label="Type"><Sel v={p.bg} opts={["none", "color", "gradient", "image", "video"] as const} on={set("bg")} /></Row>
        {p.bg === "color" && <Row label="Color"><Color v={p.bgColor} on={set("bgColor")} /></Row>}
        {p.bg === "gradient" && <>
          <Row label="From"><Color v={p.gradientFrom} on={set("gradientFrom")} /></Row>
          <Row label="To"><Color v={p.gradientTo} on={set("gradientTo")} /></Row>
          <Row label={`Angle: ${p.gradientAngle ?? 135}°`}><Slider min={0} max={360} value={[p.gradientAngle ?? 135]} onValueChange={([v]) => set("gradientAngle")(v)} /></Row>
        </>}
        {(p.bg === "image" || p.bg === "video") && <>
          <Row label="File">
            <select value={p.bgMedia ?? ""} onChange={(e) => set("bgMedia")(e.target.value)} className="h-9 rounded-md border bg-background px-2 text-sm">
              <option value="">Choose from library…</option>
              {media.filter((m) => (p.bg === "video" ? isVideo(m.path) : m.kind === "image")).map((m) => <option key={m.path} value={m.path}>{m.name}</option>)}
            </select>
          </Row>
          <Row label={`Darken: ${Math.round((p.overlay ?? 0.4) * 100)}%`}><Slider min={0} max={90} value={[(p.overlay ?? 0.4) * 100]} onValueChange={([v]) => set("overlay")((v ?? 40) / 100)} /></Row>
        </>}
      </Group>

      {hasText && (
        <Group title="Motion & light">
          <Row label="Animation"><Sel v={p.animation} opts={["none", "fade-up", "fade-in", "zoom", "slide-left", "slide-right", "float", "pulse"] as const} on={set("animation")} /></Row>
          <Toggle label="Glow effect" v={p.glow} on={set("glow")} />
          <Toggle label="Spotlight" v={p.light} on={set("light")} />
          {(p.glow || p.light) && <Row label="Light color"><Color v={p.glowColor} on={set("glowColor")} /></Row>}
        </Group>
      )}
    </div>
  );
}
