import { useEffect, useState } from "react";
import { Download, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { isVideo } from "@/lib/blocks";
import { MEDIA_BUCKET, downloadMedia, useMediaUrl } from "@/lib/media";
import { logActivity } from "@/lib/log";
import { deleteAccount } from "@/lib/users.functions";

export type MediaRow = { id: string; path: string; name: string; kind: string; created_at: string };

function Thumb({ m }: { m: MediaRow }) {
  const url = useMediaUrl(m.path);
  if (m.kind === "image") return url ? <img src={url} alt="" className="aspect-square w-full object-cover" /> : <div className="aspect-square bg-muted" />;
  if (m.kind === "video") return url ? <video src={url} muted className="aspect-square w-full object-cover" /> : <div className="aspect-square bg-muted" />;
  return <div className="flex aspect-square items-center justify-center bg-muted text-xs font-bold uppercase">{m.name.split(".").pop()}</div>;
}

export function MediaPanel({ media, reload }: { media: MediaRow[]; reload: () => void }) {
  const [busy, setBusy] = useState(false);
  async function upload(files: FileList) {
    setBusy(true);
    for (const f of Array.from(files)) {
      const path = `library/${Date.now()}-${f.name.replace(/[^\w.-]/g, "_")}`;
      const { error } = await supabase.storage.from(MEDIA_BUCKET).upload(path, f);
      if (error) { toast.error(`${f.name}: ${error.message}`); continue; }
      const kind = f.type.startsWith("image/") ? "image" : isVideo(f.name) || f.type.startsWith("video/") ? "video" : "file";
      await supabase.from("media").insert({ path, name: f.name, kind, url: path });
      await logActivity("upload", f.name);
    }
    setBusy(false); reload();
  }
  async function remove(m: MediaRow) {
    if (!confirm(`Delete ${m.name}?`)) return;
    await supabase.storage.from(MEDIA_BUCKET).remove([m.path]);
    await supabase.from("media").delete().eq("id", m.id);
    reload();
  }
  return (
    <div className="mx-auto max-w-6xl p-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Media library</h1>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
          <Upload className="size-4" /> {busy ? "Uploading…" : "Upload files"}
          <input type="file" multiple hidden onChange={(e) => e.target.files && upload(e.target.files)} />
        </label>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">Pictures and videos can be shown on the page in grid, masonry, strip, split or single layouts. Other files can be offered as downloads.</p>
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-5">
        {media.map((m) => (
          <div key={m.id} className="overflow-hidden rounded-lg border bg-card">
            <Thumb m={m} />
            <div className="flex items-center justify-between gap-1 p-2 text-xs">
              <span className="truncate">{m.name}</span>
              <span className="flex shrink-0 gap-1">
                <button onClick={() => downloadMedia(m.path)} aria-label="Download"><Download className="size-3.5" /></button>
                <button onClick={() => remove(m)} aria-label="Delete"><Trash2 className="size-3.5 text-destructive" /></button>
              </span>
            </div>
          </div>
        ))}
      </div>
      {!media.length && <p className="mt-10 text-center text-muted-foreground">No files yet.</p>}
    </div>
  );
}

export function SubmissionsPanel() {
  const [rows, setRows] = useState<{ id: string; data: Record<string, string>; created_at: string }[]>([]);
  const load = () => supabase.from("form_submissions").select("id,data,created_at").order("created_at", { ascending: false }).then(({ data }) => setRows((data as never) ?? []));
  useEffect(() => { load(); }, []);
  return (
    <div className="mx-auto max-w-4xl p-8">
      <h1 className="text-3xl font-bold">Form submissions</h1>
      <div className="mt-6 grid gap-3">
        {rows.map((r) => (
          <div key={r.id} className="rounded-lg border bg-card p-4">
            <div className="flex justify-between text-xs text-muted-foreground"><span>{new Date(r.created_at).toLocaleString()}</span>
              <button onClick={async () => { await supabase.from("form_submissions").delete().eq("id", r.id); load(); }}><Trash2 className="size-3.5" /></button></div>
            <dl className="mt-2 grid grid-cols-[120px_1fr] gap-1 text-sm">{Object.entries(r.data).map(([k, v]) => <div key={k} className="contents"><dt className="font-semibold">{k}</dt><dd className="whitespace-pre-line">{v}</dd></div>)}</dl>
          </div>
        ))}
        {!rows.length && <p className="text-muted-foreground">No submissions yet.</p>}
      </div>
    </div>
  );
}

export function UsersPanel({ meId }: { meId: string }) {
  const [users, setUsers] = useState<{ id: string; email: string | null; display_name: string | null; created_at: string; admin: boolean }[]>([]);
  async function load() {
    const [{ data: p }, { data: r }] = await Promise.all([
      supabase.from("profiles").select("id,email,display_name,created_at").order("created_at"),
      supabase.from("user_roles").select("user_id,role").eq("role", "admin"),
    ]);
    const admins = new Set((r ?? []).map((x) => x.user_id));
    setUsers((p ?? []).map((u) => ({ ...u, admin: admins.has(u.id) })));
  }
  useEffect(() => { load(); }, []);
  async function toggleAdmin(id: string, admin: boolean) {
    const { error } = admin
      ? await supabase.from("user_roles").delete().eq("user_id", id).eq("role", "admin")
      : await supabase.from("user_roles").insert({ user_id: id, role: "admin" });
    if (error) { toast.error(error.message); return; }
    await logActivity(admin ? "admin_removed" : "admin_granted", id);
    load();
  }
  async function remove(id: string, email: string | null) {
    if (!confirm(`Delete account ${email}?`)) return;
    try { await deleteAccount({ data: { userId: id } }); await logActivity("account_deleted", email ?? id); load(); }
    catch (e) { toast.error((e as Error).message); }
  }
  return (
    <div className="mx-auto max-w-4xl p-8">
      <h1 className="text-3xl font-bold">Accounts</h1>
      <table className="mt-6 w-full text-sm">
        <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="py-2">User</th><th>Joined</th><th>Role</th><th /></tr></thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id} className="border-t">
              <td className="py-3"><div className="font-semibold">{u.display_name}</div><div className="text-muted-foreground">{u.email}</div></td>
              <td>{new Date(u.created_at).toLocaleDateString()}</td>
              <td>{u.admin ? <Badge>Admin</Badge> : <Badge variant="secondary">Member</Badge>}</td>
              <td className="text-right">{u.id !== meId && <span className="flex justify-end gap-2">
                <Button size="sm" variant="outline" onClick={() => toggleAdmin(u.id, u.admin)}>{u.admin ? "Remove admin" : "Make admin"}</Button>
                <Button size="sm" variant="destructive" onClick={() => remove(u.id, u.email)}>Delete</Button></span>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function LogPanel() {
  const [rows, setRows] = useState<{ id: string; email: string | null; action: string; details: string | null; created_at: string }[]>([]);
  useEffect(() => { supabase.from("activity_log").select("*").order("created_at", { ascending: false }).limit(200).then(({ data }) => setRows(data ?? [])); }, []);
  return (
    <div className="mx-auto max-w-4xl p-8">
      <h1 className="text-3xl font-bold">Activity log</h1>
      <table className="mt-6 w-full text-sm">
        <tbody>{rows.map((r) => <tr key={r.id} className="border-t"><td className="py-2 text-muted-foreground">{new Date(r.created_at).toLocaleString()}</td><td>{r.email}</td><td className="font-semibold">{r.action.replace(/_/g, " ")}</td><td className="text-muted-foreground">{r.details}</td></tr>)}</tbody>
      </table>
      {!rows.length && <p className="mt-4 text-muted-foreground">No activity yet.</p>}
    </div>
  );
}
