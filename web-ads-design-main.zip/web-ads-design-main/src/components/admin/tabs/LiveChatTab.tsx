import { Archive, Bot, CheckCheck, Globe, Monitor, RotateCcw, Send, Smartphone, UserRound, XCircle } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { RichText } from "@/components/chat/RichText";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { notifyIncoming, timeLabel } from "@/lib/chat-client";
import type { ChatMessageRow, ThreadStatus, VisitorMeta } from "@/lib/chat-shared";
import { cn } from "@/lib/utils";

type ThreadRow = {
  id: string;
  visitor_name: string | null;
  visitor_email: string | null;
  status: ThreadStatus;
  mode: "ai" | "human";
  meta: VisitorMeta & { handoff_reason?: string };
  last_message_at: string;
  last_message_preview: string | null;
  created_at: string;
};

// Edit these canned replies to match how the team talks.
export const QUICK_REPLIES: { label: string; text: string }[] = [
  { label: "Pricing", text: "Happy to help with pricing! Our creative sprints start from $2,500 and paid-media management from $1,500/month. Every quote is tailored — what's your rough monthly budget and main goal?" },
  { label: "Book a call", text: "Let's set up a free 30-minute discovery call. What email should we send the invite to, and which days/times work best for you?" },
  { label: "Portfolio", text: "You can see recent campaigns on our site — tell me your industry and I'll send the most relevant examples." },
  { label: "Follow up", text: "Thanks for reaching out! If we get disconnected, leave your email here and we'll follow up within one business day." },
];

const FILTERS: { key: "active" | "closed" | "archived"; label: string; statuses: ThreadStatus[] }[] = [
  { key: "active", label: "Active", statuses: ["needs_human", "open"] },
  { key: "closed", label: "Closed", statuses: ["closed"] },
  { key: "archived", label: "Archived", statuses: ["archived"] },
];

export function LiveChatTab({ meId, onUnreadChange }: { meId: string; onUnreadChange?: (n: number) => void }) {
  const [threads, setThreads] = useState<ThreadRow[]>([]);
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["key"]>("active");
  const [selected, setSelected] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessageRow[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const selectedRef = useRef<string | null>(null);
  selectedRef.current = selected;

  const loadThreads = useCallback(async () => {
    const [{ data: t }, { data: u }] = await Promise.all([
      supabase.from("chat_threads").select("id,visitor_name,visitor_email,status,mode,meta,last_message_at,last_message_preview,created_at").eq("type", "visitor").order("last_message_at", { ascending: false }).limit(200),
      supabase.from("chat_messages").select("thread_id").eq("sender_type", "visitor").eq("is_read", false).limit(1000),
    ]);
    setThreads((t as ThreadRow[] | null) ?? []);
    const counts: Record<string, number> = {};
    for (const r of u ?? []) counts[r.thread_id] = (counts[r.thread_id] ?? 0) + 1;
    setUnread(counts);
  }, []);

  const loadMessages = useCallback(async (threadId: string) => {
    const { data } = await supabase.from("chat_messages").select("*").eq("thread_id", threadId).order("created_at").limit(500);
    if (selectedRef.current === threadId) setMessages((data as ChatMessageRow[] | null) ?? []);
    await supabase.from("chat_messages").update({ is_read: true }).eq("thread_id", threadId).eq("sender_type", "visitor").eq("is_read", false);
    setUnread((u) => ({ ...u, [threadId]: 0 }));
  }, []);

  useEffect(() => { loadThreads(); }, [loadThreads]);
  useEffect(() => { if (selected) loadMessages(selected); else setMessages([]); }, [selected, loadMessages]);

  useEffect(() => {
    const ch = supabase
      .channel(`studio-inbox-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, (payload) => {
        const m = payload.new as ChatMessageRow;
        if (m.sender_type === "member") return;
        if (m.thread_id === selectedRef.current) {
          setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
          if (m.sender_type === "visitor") supabase.from("chat_messages").update({ is_read: true }).eq("id", m.id).then(() => {});
        }
        if (m.sender_type === "visitor") {
          notifyIncoming(true);
          if (m.thread_id !== selectedRef.current) toast(`New chat message`, { description: m.content.slice(0, 80) });
        }
        loadThreads();
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "chat_threads" }, () => loadThreads())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [loadThreads]);

  const totalUnread = useMemo(() => Object.values(unread).reduce((a, b) => a + b, 0) + threads.filter((t) => t.status === "needs_human").length, [unread, threads]);
  useEffect(() => { onUnreadChange?.(totalUnread); }, [totalUnread, onUnreadChange]);

  const visible = threads.filter((t) => FILTERS.find((f) => f.key === filter)!.statuses.includes(t.status))
    .sort((a, b) => (a.status === "needs_human" ? -1 : 0) - (b.status === "needs_human" ? -1 : 0) || b.last_message_at.localeCompare(a.last_message_at));
  const thread = threads.find((t) => t.id === selected);

  async function setStatus(status: ThreadStatus, mode?: "ai" | "human") {
    if (!thread) return;
    const { error } = await supabase.from("chat_threads").update({ status, ...(mode ? { mode } : {}) }).eq("id", thread.id);
    if (error) toast.error(error.message);
    loadThreads();
  }

  async function send() {
    const text = draft.trim();
    if (!text || !thread) return;
    setSending(true);
    const { error } = await supabase.from("chat_messages").insert({ thread_id: thread.id, sender_type: "admin", sender_id: meId, content: text });
    setSending(false);
    if (error) { toast.error(error.message); return; }
    setDraft("");
    if (thread.status !== "open" || thread.mode !== "human") await supabase.from("chat_threads").update({ status: "open", mode: "human" }).eq("id", thread.id);
  }

  return (
    <div className="grid h-[calc(100vh-57px)] grid-cols-[320px_1fr]">
      <aside className="flex min-h-0 flex-col border-r bg-card">
        <div className="border-b p-3">
          <h1 className="text-xl font-bold">Live chat</h1>
          <div className="mt-2 flex gap-1">
            {FILTERS.map((f) => (
              <button key={f.key} onClick={() => setFilter(f.key)} className={cn("rounded-full px-3 py-1 text-xs font-semibold", filter === f.key ? "bg-secondary text-secondary-foreground" : "bg-muted hover:bg-accent")}>{f.label}</button>
            ))}
          </div>
        </div>
        <ul className="min-h-0 flex-1 overflow-y-auto">
          {visible.map((t) => (
            <li key={t.id}>
              <button onClick={() => setSelected(t.id)} className={cn("grid w-full gap-1 border-b px-3 py-3 text-left hover:bg-muted", selected === t.id && "bg-accent")}>
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate font-semibold">{t.visitor_name || t.visitor_email || `Visitor ${t.id.slice(0, 4).toUpperCase()}`}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">{timeLabel(t.last_message_at)}</span>
                </div>
                <p className="truncate text-xs text-muted-foreground">{t.last_message_preview || "No messages yet"}</p>
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                  {t.status === "needs_human" && <Badge className="h-5 px-1.5 text-[10px]">Needs human</Badge>}
                  {t.mode === "ai" && <Badge variant="secondary" className="h-5 gap-1 px-1.5 text-[10px]"><Bot className="size-3" />AI</Badge>}
                  {(unread[t.id] ?? 0) > 0 && <Badge variant="destructive" className="h-5 px-1.5 text-[10px]">{unread[t.id]} new</Badge>}
                  <span className="flex items-center gap-1">{t.meta?.device === "Mobile" ? <Smartphone className="size-3" /> : <Monitor className="size-3" />}{[t.meta?.country, t.meta?.browser].filter(Boolean).join(" · ")}</span>
                </div>
              </button>
            </li>
          ))}
          {!visible.length && <li className="p-6 text-center text-sm text-muted-foreground">No conversations here.</li>}
        </ul>
      </aside>

      {thread ? (
        <section className="flex min-h-0 flex-col">
          <header className="flex flex-wrap items-center justify-between gap-3 border-b bg-card px-5 py-3">
            <div>
              <p className="font-semibold">{thread.visitor_name || `Visitor ${thread.id.slice(0, 4).toUpperCase()}`} {thread.visitor_email && <a href={`mailto:${thread.visitor_email}`} className="ml-1 text-sm font-normal text-primary underline">{thread.visitor_email}</a>}</p>
              <p className="mt-0.5 flex flex-wrap items-center gap-x-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Globe className="size-3" />{[thread.meta?.country, thread.meta?.timezone].filter(Boolean).join(" · ") || "Unknown location"}</span>
                <span>{[thread.meta?.device, thread.meta?.os, thread.meta?.browser].filter(Boolean).join(" · ")}</span>
                {thread.meta?.page && <span>on {thread.meta.page}</span>}
                {thread.meta?.handoff_reason && <span className="text-foreground">Handoff: {thread.meta.handoff_reason}</span>}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {thread.mode === "ai" && <Button size="sm" variant="outline" onClick={() => setStatus("open", "human")}><UserRound />Take over from AI</Button>}
              {thread.status === "closed" || thread.status === "archived" ? (
                <Button size="sm" variant="outline" onClick={() => setStatus("open")}><RotateCcw />Reopen</Button>
              ) : (
                <Button size="sm" variant="outline" onClick={() => setStatus("closed")}><XCircle />Close</Button>
              )}
              {thread.status !== "archived" && <Button size="sm" variant="ghost" onClick={() => setStatus("archived")}><Archive />Archive</Button>}
            </div>
          </header>
          <div className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-background px-5 py-4" ref={(el) => { if (el) el.scrollTop = el.scrollHeight; }}>
            {messages.map((m) => {
              const mine = m.sender_type === "admin";
              return (
                <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[70%] rounded-2xl px-4 py-2.5 text-sm", mine ? "bg-primary text-primary-foreground" : m.sender_type === "ai" ? "border border-dashed bg-card" : "bg-secondary text-secondary-foreground")}>
                    <p className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide opacity-70">{m.sender_type === "ai" ? "AI Strategist" : m.sender_type === "admin" ? "Team" : "Visitor"} · {timeLabel(m.created_at)}{mine && m.is_read && <CheckCheck className="ml-1 inline size-3" />}</p>
                    <RichText text={m.content} />
                  </div>
                </div>
              );
            })}
          </div>
          <footer className="border-t bg-card p-3">
            <div className="mb-2 flex flex-wrap gap-1.5">
              {QUICK_REPLIES.map((q) => (
                <button key={q.label} onClick={() => setDraft(q.text)} className="rounded-full border px-3 py-1 text-xs font-semibold hover:bg-accent">{q.label}</button>
              ))}
            </div>
            <div className="flex gap-2">
              <Textarea value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Reply to visitor…" className="min-h-11" onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} />
              <Button onClick={send} disabled={sending || !draft.trim()} className="self-end"><Send />Send</Button>
            </div>
          </footer>
        </section>
      ) : (
        <div className="flex items-center justify-center text-muted-foreground">Select a conversation</div>
      )}
    </div>
  );
}
