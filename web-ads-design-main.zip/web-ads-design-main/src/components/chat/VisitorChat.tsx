import { ClientOnly } from "@tanstack/react-router";
import { Suspense, lazy } from "react";

// The widget only runs in the browser (visitor id lives in localStorage), so load it after hydration.
const VisitorChatWidget = lazy(() => import("./VisitorChatWidget"));

export function VisitorChat() {
  return (
    <ClientOnly>
      <Suspense fallback={null}>
        <VisitorChatWidget />
      </Suspense>
    </ClientOnly>
  );
}
