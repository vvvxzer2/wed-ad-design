import { Fragment, type ReactNode } from "react";

// Minimal, safe formatting for human chat: **bold**, _italic_, `code` and auto-linked URLs.
const TOKEN = /(\*\*[^*]+\*\*|_[^_]+_|`[^`]+`|https?:\/\/[^\s<]+)/g;

export function RichText({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <>
      {lines.map((line, li) => (
        <Fragment key={li}>
          {li > 0 && <br />}
          {line.split(TOKEN).map((part, i): ReactNode => {
            if (!part) return null;
            if (part.startsWith("**") && part.endsWith("**") && part.length > 4) return <strong key={i}>{part.slice(2, -2)}</strong>;
            if (part.startsWith("_") && part.endsWith("_") && part.length > 2) return <em key={i}>{part.slice(1, -1)}</em>;
            if (part.startsWith("`") && part.endsWith("`") && part.length > 2) return <code key={i} className="rounded bg-muted px-1 py-0.5 text-[0.85em] text-foreground">{part.slice(1, -1)}</code>;
            if (/^https?:\/\//.test(part)) return <a key={i} href={part} target="_blank" rel="noreferrer noopener" className="underline underline-offset-2 break-all">{part}</a>;
            return <Fragment key={i}>{part}</Fragment>;
          })}
        </Fragment>
      ))}
    </>
  );
}
