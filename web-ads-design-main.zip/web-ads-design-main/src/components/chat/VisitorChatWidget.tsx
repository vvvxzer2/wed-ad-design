import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, isToolUIPart, type UIMessage } from "ai";
import { Bot, Flame, UserRound, Volume2, VolumeX, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Conversation, ConversationContent, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputFooter, PromptInputSubmit, PromptInputTextarea, type PromptInputMessage } from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Tool, ToolContent, ToolHeader, ToolInput, ToolOutput } from "@/components/ai-elements/tool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { collectVisitorMeta, isInvalidSessionError, notifyIncoming, readVisitorToken, saveVisitorToken, timeLabel } from "@/lib/chat-client";
import { visitorIdFromToken, type ThreadMode } from "@/lib/chat-shared";
import { cn } from "@/lib/utils";
import { getVisitorChat, sendVisitorMessage, setVisitorMode, startVisitorSession, updateVisitorInfo, type VisitorMessage } from "@/lib/visitor-chat.functions";

const SOUND_KEY = "flare_chat_sound";
const SEEN_KEY = "flare_chat_seen";
const INFO_KEY = "flare_chat_info_done";

const TOOL_TITLES: Record<string, string> = { capture_lead: "Saving your details", request_human: "Bringing in the team" };

function AiAvatar() {
  return <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-gradient-flame text-secondary-foreground"><Flame className="size-3.5" /></span>;
}

/** Gets (or creates) the visitor's server-signed chat session, then shows the widget. */
export default function VisitorChatWidget() {
  const [token, setToken] = useState<string | null>(() => readVisitorToken());
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (token || failed) return;
    let cancelled = false;
    startVisitorSession()
      .then((r) => {
        if (cancelled) return;
        saveVisitorToken(r.token);
        setToken(r.token);
      })
      .catch(() => !cancelled && setFailed(true));
    return () => {
      cancelled = true;
    };
  }, [token, failed]);

  const reset = useCallback(() => {
    saveVisitorToken(null);
    setToken(null);
  }, []);

  if (!token) return null;
  return <ChatWidget key={token} token={token} onInvalidSession={reset} />;
}

function ChatWidget({ token, onInvalidSession }: { token: string; onInvalidSession: () => void }) {
  const [open, setOpen] = useState(false);
  const visitorId = visitorIdFromToken(token) ?? "";
  const [sound, setSound] = useState(() => localStorage.getItem(SOUND_KEY) !== "off");
  const [mode, setMode] = useState<ThreadMode>("ai");
  const [rows, setRows] = useState<VisitorMessage[]>([]);
  const [hasInfo, setHasInfo] = useState(false);
  const [askInfo, setAskInfo] = useState(false);
  const [online, setOnline] = useState(false);
  const [seenAt, setSeenAt] = useState(() => localStorage.getItem(SEEN_KEY) ?? "");
  const [sending, setSending] = useState(false);
  const busyRef = useRef(false);
  const lastIncomingRef = useRef<string | null>(null);
  const soundRef = useRef(sound);
  soundRef.current = sound;

  const refresh = useCallback(async () => {
    let r: Awaited<ReturnType<typeof getVisitorChat>>;
    try {
      r = await getVisitorChat({ data: { token } });
    } catch (e) {
      if (isInvalidSessionError(e)) onInvalidSession();
      throw e;
    }
    setRows(r.messages);
    if (r.thread) {
      setMode(r.thread.mode as ThreadMode);
      setHasInfo(!!(r.thread.visitor_email || r.thread.visitor_name));
    }
    const incoming = r.messages.filter((m) => m.sender_type === "admin").at(-1);
    if (incoming && lastIncomingRef.current && incoming.id !== lastIncomingRef.current) notifyIncoming(soundRef.current);
    lastIncomingRef.current = incoming?.id ?? lastIncomingRef.current ?? "none";
    return r;
  }, [token, onInvalidSession]);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/public/assistant",
        prepareSendMessagesRequest: ({ messages }) => {
          const last = messages.at(-1);
          const text = last?.parts.map((p) => (p.type === "text" ? p.text : "")).join("") ?? "";
          return { body: { token, text, meta: collectVisitorMeta() } };
        },
      }),
    [token],
  );

  const chat = useChat({
    transport,
    onError: (e) => {
      if (isInvalidSessionError(e)) {
        onInvalidSession();
        return;
      }
      let msg = e.message;
      try {
        msg = (JSON.parse(e.message) as { error?: string }).error ?? msg;
      } catch {
        /* plain text */
      }
      toast.error(msg || "The AI strategist couldn't reply. Please try again.");
    },
    onFinish: async () => {
      try {
        await refresh();
      } finally {
        chat.setMessages([]);
        busyRef.current = false;
      }
    },
  });
  const aiBusy = chat.status === "submitted" || chat.status === "streaming";
  busyRef.current = aiBusy;

  // Initial history + realtime doorbell for team replies.
  useEffect(() => {
    refresh().catch(() => {});
    const bell = supabase
      .channel(`visitor:${visitorId}`)
      .on("broadcast", { event: "new_message" }, () => {
        if (!busyRef.current) refresh().catch(() => {});
      })
      .subscribe();
    const presence = supabase.channel("studio-presence");
    presence.on("presence", { event: "sync" }, () => setOnline(Object.keys(presence.presenceState()).length > 0)).subscribe();
    return () => {
      supabase.removeChannel(bell);
      supabase.removeChannel(presence);
    };
  }, [refresh, visitorId]);

  // Fallback refresh while the panel is open, in case the realtime connection drops.
  useEffect(() => {
    if (!open) return;
    const t = setInterval(() => !busyRef.current && refresh().catch(() => {}), 30000);
    return () => clearInterval(t);
  }, [open, refresh]);

  const latest = rows.at(-1)?.created_at ?? "";
  useEffect(() => {
    if (open && latest) {
      localStorage.setItem(SEEN_KEY, latest);
      setSeenAt(latest);
    }
  }, [open, latest]);
  const unread = open ? 0 : rows.filter((m) => m.sender_type !== "visitor" && m.created_at > seenAt).length;

  function toggleSound() {
    const next = !sound;
    setSound(next);
    localStorage.setItem(SOUND_KEY, next ? "on" : "off");
    if (next) notifyIncoming(true);
  }

  async function switchMode(next: ThreadMode) {
    if (next === mode || aiBusy) return;
    setMode(next);
    try {
      await setVisitorMode({ data: { token, mode: next } });
    } catch {
      /* thread may not exist yet; mode is applied on first message */
    }
  }

  async function submit(msg: PromptInputMessage) {
    const text = msg.text.trim();
    if (!text || aiBusy || sending) return;
    if (mode === "ai") {
      await chat.sendMessage({ text });
      return;
    }
    setSending(true);
    const temp: VisitorMessage = { id: `tmp-${Date.now()}`, sender_type: "visitor", content: text, created_at: new Date().toISOString() };
    setRows((r) => [...r, temp]);
    try {
      await sendVisitorMessage({ data: { token, content: text, meta: collectVisitorMeta() } });
      await refresh();
      if (!hasInfo && !localStorage.getItem(INFO_KEY)) setAskInfo(true);
    } catch (e) {
      setRows((r) => r.filter((m) => m.id !== temp.id));
      if (isInvalidSessionError(e)) {
        onInvalidSession();
        return;
      }
      toast.error((e as Error).message || "Message not sent");
      throw e;
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      {open && (
        <section
          aria-label="Chat with FLARE"
          className="flex h-[min(620px,calc(100dvh-7rem))] w-[min(390px,calc(100vw-2.5rem))] flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl animate-in fade-in slide-in-from-bottom-4"
        >
          <header className="bg-gradient-flame-soft px-4 pb-3 pt-4 text-secondary-foreground">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-display text-lg font-extrabold leading-none text-primary">FLARE®</p>
                <p className="mt-1.5 flex items-center gap-1.5 text-xs opacity-80">
                  <span className={cn("size-2 rounded-full", online ? "bg-success" : "bg-muted-foreground")} />
                  {online ? "Team online now" : "Team away — we reply within a day"}
                </p>
              </div>
              <div className="flex items-center gap-1">
                <Button size="icon-sm" variant="ghost-inverse" onClick={toggleSound} aria-label={sound ? "Mute sounds" : "Turn sounds on"}>
                  {sound ? <Volume2 /> : <VolumeX />}
                </Button>
                <Button size="icon-sm" variant="ghost-inverse" onClick={() => setOpen(false)} aria-label="Close chat"><X /></Button>
              </div>
            </div>
            <div role="tablist" aria-label="Who to chat with" className="mt-3 grid grid-cols-2 gap-1 rounded-full bg-sidebar-accent p-1 text-xs font-semibold">
              {([["ai", "AI Strategist", Bot], ["human", "Talk to a human", UserRound]] as const).map(([m, label, Icon]) => (
                <button
                  key={m}
                  role="tab"
                  aria-selected={mode === m}
                  onClick={() => switchMode(m)}
                  className={cn("flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 transition-colors", mode === m ? "bg-primary text-primary-foreground" : "hover:bg-sidebar-border")}
                >
                  <Icon className="size-3.5" /> {label}
                </button>
              ))}
            </div>
          </header>

          <Conversation className="min-h-0 flex-1">
            <ConversationContent className="gap-5 p-4">
              <Message from="assistant">
                <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><AiAvatar /> FLARE</div>
                <MessageContent>
                  <p>
                    Hey 👋 Welcome to FLARE. {mode === "ai"
                      ? "I'm the AI Strategist — ask me about ads, creative or pricing, any time."
                      : "Leave us a message and a strategist will reply right here."}
                  </p>
                </MessageContent>
              </Message>

              {rows.map((m) =>
                m.sender_type === "visitor" ? (
                  <Message key={m.id} from="user">
                    <MessageContent className="whitespace-pre-wrap">{m.content}</MessageContent>
                    <span className="ml-auto text-[10px] text-muted-foreground">{timeLabel(m.created_at)}</span>
                  </Message>
                ) : (
                  <Message key={m.id} from="assistant">
                    <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                      {m.sender_type === "ai" ? <><AiAvatar /> AI Strategist</> : <><span className="flex size-6 items-center justify-center rounded-full bg-secondary text-[10px] font-bold text-secondary-foreground">FL</span> FLARE team</>}
                      <span className="font-normal">· {timeLabel(m.created_at)}</span>
                    </div>
                    <MessageContent className={cn(m.sender_type === "admin" && "border-l-2 border-primary pl-3")}>
                      <MessageResponse>{m.content}</MessageResponse>
                    </MessageContent>
                  </Message>
                ),
              )}

              {chat.messages.map((m: UIMessage) =>
                m.role === "user" ? (
                  <Message key={m.id} from="user">
                    <MessageContent className="whitespace-pre-wrap">{m.parts.map((p) => (p.type === "text" ? p.text : "")).join("")}</MessageContent>
                  </Message>
                ) : (
                  <Message key={m.id} from="assistant">
                    <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><AiAvatar /> AI Strategist</div>
                    <MessageContent>
                      {m.parts.map((p, i) => {
                        if (p.type === "text") return <MessageResponse key={i} isAnimating={chat.status === "streaming"}>{p.text}</MessageResponse>;
                        if (isToolUIPart(p)) {
                          const name = p.type.replace(/^tool-/, "");
                          return (
                            <Tool key={i} defaultOpen={false} className="mb-0">
                              <ToolHeader type={p.type as `tool-${string}`} state={p.state} title={TOOL_TITLES[name] ?? name} />
                              <ToolContent>
                                <ToolInput input={p.input} />
                                <ToolOutput output={p.output} errorText={p.errorText} />
                              </ToolContent>
                            </Tool>
                          );
                        }
                        return null;
                      })}
                      {!m.parts.some((p) => p.type === "text" && p.text) && aiBusy && <Shimmer className="text-sm">Thinking…</Shimmer>}
                    </MessageContent>
                  </Message>
                ),
              )}
              {chat.status === "submitted" && chat.messages.at(-1)?.role === "user" && (
                <Message from="assistant">
                  <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><AiAvatar /> AI Strategist</div>
                  <Shimmer className="text-sm">Thinking…</Shimmer>
                </Message>
              )}

              {askInfo && <InfoCard token={token} onDone={(saved) => { setAskInfo(false); localStorage.setItem(INFO_KEY, "1"); if (saved) setHasInfo(true); }} />}
            </ConversationContent>
            <ConversationScrollButton />
          </Conversation>

          <div className="border-t p-3">
            <PromptInput onSubmit={submit}>
              <PromptInputTextarea placeholder={mode === "ai" ? "Ask the AI strategist…" : "Message the FLARE team…"} className="min-h-12" />
              <PromptInputFooter className="justify-between">
                <span className="text-[11px] text-muted-foreground">{mode === "ai" ? "AI replies instantly · type “human” anytime" : "A real person will reply"}</span>
                <PromptInputSubmit status={mode === "ai" ? chat.status : sending ? "submitted" : "ready"} onStop={chat.stop} />
              </PromptInputFooter>
            </PromptInput>
          </div>
        </section>
      )}

      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? "Close chat" : "Chat with FLARE"}
        className="relative flex size-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-glow transition-transform hover:scale-105 active:scale-95"
      >
        {open ? <X className="size-6" /> : <Flame className="size-7" />}
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex min-w-5 items-center justify-center rounded-full bg-secondary px-1.5 text-[11px] font-bold text-secondary-foreground ring-2 ring-background">
            {unread}
          </span>
        )}
      </button>
    </div>
  );
}

function InfoCard({ token, onDone }: { token: string; onDone: (saved: boolean) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await updateVisitorInfo({ data: { token, name: name || undefined, email: email || undefined } as never });
      toast.success("Thanks — we'll follow up if you step away.");
      onDone(true);
    } catch {
      toast.error("Please check your email address.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={save} className="grid gap-2 rounded-xl border bg-muted p-3 text-sm">
      <p className="font-semibold">Want a reply even if you leave?</p>
      <p className="text-xs text-muted-foreground">Optional — leave your name and email for offline replies.</p>
      <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
      <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <div className="flex justify-end gap-2">
        <Button type="button" size="sm" variant="ghost" onClick={() => onDone(false)}>Skip</Button>
        <Button type="submit" size="sm" disabled={busy || (!name && !email)}>Save</Button>
      </div>
    </form>
  );
}
