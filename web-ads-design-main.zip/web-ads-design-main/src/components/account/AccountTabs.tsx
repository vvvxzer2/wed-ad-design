import { Link } from "@tanstack/react-router";

const TABS = [
  { to: "/account", label: "Profile" },
  { to: "/account/messages", label: "Messages" },
  { to: "/account/deliverables", label: "Deliverables" },
] as const;

export function AccountTabs() {
  return (
    <nav className="mx-auto mt-6 flex max-w-6xl gap-1 px-6" aria-label="Account sections">
      {TABS.map((t) => (
        <Link
          key={t.to}
          to={t.to}
          activeOptions={{ exact: true }}
          className="rounded-full px-4 py-1.5 text-sm font-semibold text-muted-foreground hover:bg-muted"
          activeProps={{ className: "bg-secondary text-secondary-foreground hover:bg-secondary" }}
        >
          {t.label}
        </Link>
      ))}
    </nav>
  );
}
