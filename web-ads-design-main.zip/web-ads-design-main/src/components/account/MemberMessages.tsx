import { Check, CheckCheck, FileText, Paperclip, Search, Send } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { RichText } from "@/components/chat/RichText";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { timeLabel } from "@/lib/chat-client";
import type { ChatMessageRow } from "@/lib/chat-shared";
import { useMediaUrl } from "@/lib/media";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

const ATTACHMENTS_BUCKET = "attachments";

type ThreadSummary = {
  thread_id: string;
  other_id: string;
  other_name: string | null;
  other_email: string | null;
  other_avatar: string | null;
  other_last_read_at: string;
  last_message_at: string;
  last_message_preview: string | null;
  unread: number;
};
type Member = { id: string; display_name: string | null; email: string | null; avatar_url: string | null };

function Avatar({ path, name }: { path: string | null; name: string | null }) {
  const url = useMediaUrl(path ?? undefined);
  return (
    <span className="flex size-9 shrink-0 items-center justify-center overflow-hidden rounded-full bg-secondary text-xs font-bold text-secondary-foreground">
      {url ? <img src={url} alt="" className="size-full object-cover" /> : (name ?? "?").slice(0, 2).toUpperCase()}
    </span>
  );
}

function useAttachmentUrl(path: string | null) {
  return useQuery({
    queryKey: ["attachment", path],
    enabled: !!path,
    staleTime: 1000 * 60 * 50,
    queryFn: async () => {
      const { data, error } = await supabase.storage.from(ATTACHMENTS_BUCKET).createSignedUrl(path!, 60 * 60);
      if (error) throw error;
      return data.signedUrl;
    },
  }).data;
}

function Attachment({ m, mine }: { m: ChatMessageRow; mine: boolean }) {
  const url = useAttachmentUrl(m.attachment_path);
  if (!m.attachment_path) return null;
  if (m.attachment_type?.startsWith("image/")) {
    return url ? (
      <a href={url} target="_blank" rel="noreferrer" aria-label={`Open shared image${m.attachment_name ? `: ${m.attachment_name}` : ""}`}><img src={url} alt={m.attachment_name ? `Shared image: ${m.attachment_name}` : "Shared image attachment"} className="max-h-64 rounded-lg object-cover" /></a>
    ) : <div className="h-40 w-56 animate-pulse rounded-lg bg-muted" />;
  }
  return (
    <a href={url} target="_blank" rel="noreferrer" className={cn("flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold", mine ? "border-primary-foreground/30" : "")}>
      <FileText className="size-4" /> {m.attachment_name ?? "File"}
    </a>
  );
}

export function MemberMessages({ meId }: { meId: string }) {
  const [threads, setThreads] = useState<ThreadSummary[]>([]);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Member[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessageRow[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [typing, setTyping] = useState(false);
  const activeRef = useRef<string | null>(null);
  activeRef.current = active;
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const typingTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const lastTypingSent = useRef(0);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const loadThreads = useCallback(async () => {
    const { data } = await supabase.rpc("my_member_threads");
    setThreads((data as ThreadSummary[] | null) ?? []);
  }, []);

  const markRead = useCallback(async (threadId: string) => {
    await supabase.from("thread_participants").update({ last_read_at: new Date().toISOString() }).eq("thread_id", threadId).eq("user_id", meId);
    setThreads((ts) => ts.map((t) => (t.thread_id === threadId ? { ...t, unread: 0 } : t)));
  }, [meId]);

  useEffect(() => { loadThreads(); }, [loadThreads]);

  // Directory search
  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const t = setTimeout(() => {
      supabase.rpc("search_members", { _q: query.trim() }).then(({ data }) => setResults((data as Member[] | null) ?? []));
    }, 250);
    return () => clearTimeout(t);
  }, [query]);

  // Live updates for all my conversations (RLS only delivers rows I can read).
  useEffect(() => {
    const ch = supabase
      .channel(`dm-inbox-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, (payload) => {
        const m = payload.new as ChatMessageRow;
        if (m.sender_type !== "member") return;
        if (m.thread_id === activeRef.current) {
          setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
          if (m.sender_id !== meId) { setTyping(false); markRead(m.thread_id); }
        }
        loadThreads();
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "thread_participants" }, () => loadThreads())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [loadThreads, markRead, meId]);

  // Active conversation: history + typing indicator room.
  useEffect(() => {
    if (!active) return;
    setMessages([]);
    setTyping(false);
    supabase.from("chat_messages").select("*").eq("thread_id", active).order("created_at").limit(500).then(({ data }) => {
      if (activeRef.current === active) setMessages((data as ChatMessageRow[] | null) ?? []);
    });
    markRead(active);
    const room = supabase.channel(`dm:${active}`);
    room.on("broadcast", { event: "typing" }, ({ payload }) => {
      if (payload?.userId === meId) return;
      setTyping(true);
      clearTimeout(typingTimer.current);
      typingTimer.current = setTimeout(() => setTyping(false), 3000);
    }).subscribe();
    channelRef.current = room;
    return () => { supabase.removeChannel(room); channelRef.current = null; };
  }, [active, markRead, meId]);

  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }); }, [messages, typing]);

  async function startWith(m: Member) {
    const { data, error } = await supabase.rpc("start_direct_thread", { _other: m.id });
    if (error) { toast.error(error.message); return; }
    setQuery(""); setResults([]);
    await loadThreads();
    setActive(data as string);
  }

  function onDraftChange(v: string) {
    setDraft(v);
    const now = Date.now();
    if (channelRef.current && now - lastTypingSent.current > 1500) {
      lastTypingSent.current = now;
      channelRef.current.send({ type: "broadcast", event: "typing", payload: { userId: meId } });
    }
  }

  async function send(attachment?: { path: string; name: string; type: string }) {
    const text = draft.trim();
    if ((!text && !attachment) || !active) return;
    setSending(true);
    const { data, error } = await supabase.from("chat_messages").insert({
      thread_id: active, sender_type: "member", sender_id: meId, content: attachment ? "" : text,
      ...(attachment ? { attachment_path: attachment.path, attachment_name: attachment.name, attachment_type: attachment.type } : {}),
    }).select("*").single();
    setSending(false);
    if (error) { toast.error(error.message); return; }
    if (!attachment) setDraft("");
    setMessages((prev) => (prev.some((x) => x.id === data.id) ? prev : [...prev, data as ChatMessageRow]));
  }

  async function attach(file: File) {
    if (!active) return;
    if (file.size > 20 * 1024 * 1024) { toast.error("Files must be under 20 MB"); return; }
    const path = `${active}/${meId}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
    const { error } = await supabase.storage.from(ATTACHMENTS_BUCKET).upload(path, file, { contentType: file.type || undefined });
    if (error) { toast.error(error.message); return; }
    await send({ path, name: file.name, type: file.type || "application/octet-stream" });
  }

  const current = threads.find((t) => t.thread_id === active);

  return (
    <div className="mx-auto mt-6 grid h-[calc(100vh-14rem)] min-h-[480px] max-w-6xl grid-cols-1 overflow-hidden rounded-xl border bg-card md:grid-cols-[300px_1fr]">
      <aside className={cn("flex min-h-0 flex-col border-r", active && "hidden md:flex")}>
        <div className="border-b p-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
            <Input placeholder="Find people by full name or email" value={query} onChange={(e) => setQuery(e.target.value)} className="pl-8" />
          </div>
          {results.length > 0 && (
            <ul className="mt-2 grid gap-1">
              {results.map((m) => (
                <li key={m.id}>
                  <button onClick={() => startWith(m)} className="flex w-full items-center gap-2 rounded-md p-2 text-left hover:bg-muted">
                    <Avatar path={m.avatar_url} name={m.display_name} />
                    <span className="min-w-0"><span className="block truncate text-sm font-semibold">{m.display_name}</span><span className="block truncate text-xs text-muted-foreground">{m.email}</span></span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          {query.trim() && !results.length && <p className="mt-2 px-1 text-xs text-muted-foreground">No members found. Try their full name or email.</p>}
        </div>
        <ul className="min-h-0 flex-1 overflow-y-auto">
          {threads.map((t) => (
            <li key={t.thread_id}>
              <button onClick={() => setActive(t.thread_id)} className={cn("flex w-full items-center gap-3 border-b px-3 py-3 text-left hover:bg-muted", active === t.thread_id && "bg-accent")}>
                <Avatar path={t.other_avatar} name={t.other_name} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2"><span className="truncate text-sm font-semibold">{t.other_name ?? t.other_email}</span><span className="shrink-0 text-[11px] text-muted-foreground">{timeLabel(t.last_message_at)}</span></span>
                  <span className="flex items-center justify-between gap-2"><span className="truncate text-xs text-muted-foreground">{t.last_message_preview ?? "Say hello 👋"}</span>{t.unread > 0 && <span className="rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">{t.unread}</span>}</span>
                </span>
              </button>
            </li>
          ))}
          {!threads.length && <li className="p-6 text-center text-sm text-muted-foreground">No conversations yet. Search for a team member above to start one.</li>}
        </ul>
      </aside>

      {current ? (
        <section className="flex min-h-0 flex-col">
          <header className="flex items-center gap-3 border-b px-4 py-3">
            <button className="text-sm font-semibold text-muted-foreground md:hidden" onClick={() => setActive(null)}>← Back</button>
            <Avatar path={current.other_avatar} name={current.other_name} />
            <div className="min-w-0">
              <p className="truncate font-semibold">{current.other_name ?? current.other_email}</p>
              <p className="text-xs text-muted-foreground">{typing ? <span className="text-primary">typing…</span> : current.other_email}</p>
            </div>
          </header>
          <div ref={scrollRef} className="min-h-0 flex-1 space-y-2 overflow-y-auto bg-background px-4 py-4">
            {messages.map((m) => {
              const mine = m.sender_id === meId;
              const seen = mine && current.other_last_read_at >= m.created_at;
              return (
                <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
                  <div className={cn("grid max-w-[75%] gap-1.5 rounded-2xl px-3.5 py-2 text-sm", mine ? "bg-primary text-primary-foreground" : m.sender_type === "admin" ? "border bg-card" : "bg-secondary text-secondary-foreground")}>
                    <Attachment m={m} mine={mine} />
                    {m.content && <div className="whitespace-pre-wrap break-words"><RichText text={m.content} /></div>}
                    <span className="flex items-center justify-end gap-1 text-[10px] opacity-70">
                      {timeLabel(m.created_at)}
                      {mine && (seen ? <CheckCheck className="size-3.5" aria-label="Read" /> : <Check className="size-3.5" aria-label="Sent" />)}
                    </span>
                  </div>
                </div>
              );
            })}
            {typing && <div className="flex"><span className="rounded-2xl bg-muted px-3 py-2 text-xs text-muted-foreground">typing…</span></div>}
          </div>
          <footer className="border-t p-3">
            <div className="flex items-end gap-2">
              <label className="flex size-9 shrink-0 cursor-pointer items-center justify-center rounded-md border hover:bg-muted" aria-label="Attach a file">
                <Paperclip className="size-4" />
                <input type="file" hidden accept="image/*,video/*,application/pdf,.zip,.doc,.docx,.ppt,.pptx,.key" onChange={(e) => { const f = e.target.files?.[0]; if (f) attach(f); e.target.value = ""; }} />
              </label>
              <Textarea
                value={draft}
                onChange={(e) => onDraftChange(e.target.value)}
                placeholder="Write a message… **bold**, _italic_, links work"
                className="min-h-10"
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              />
              <Button onClick={() => send()} disabled={sending || !draft.trim()} size="icon" aria-label="Send"><Send /></Button>
            </div>
          </footer>
        </section>
      ) : (
        <div className="hidden items-center justify-center p-8 text-center text-muted-foreground md:flex">Pick a conversation, or search for someone to message.</div>
      )}
    </div>
  );
}
