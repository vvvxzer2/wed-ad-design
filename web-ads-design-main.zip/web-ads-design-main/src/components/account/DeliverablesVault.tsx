import { useQuery } from "@tanstack/react-query";
import { Download, FileText, Play, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { ASPECTS, formatBytes, signedDeliverableUrl, type AspectRatio, type DeliverableRow } from "@/lib/deliverables";
import { logActivity } from "@/lib/log";
import { cn } from "@/lib/utils";

const FRAME: Record<AspectRatio, string> = { "1:1": "aspect-square", "9:16": "aspect-[9/16]", "16:9": "aspect-video", "4:5": "aspect-[4/5]", other: "aspect-[4/3]" };

function Preview({ d }: { d: DeliverableRow }) {
  const { data: url } = useQuery({
    queryKey: ["deliverable-preview", d.path],
    enabled: d.kind !== "document",
    staleTime: 1000 * 60 * 4,
    queryFn: () => signedDeliverableUrl(d.path),
  });
  return (
    <div className="flex items-center justify-center bg-muted p-3">
      <div className={cn("relative w-full max-h-72 overflow-hidden rounded-md bg-secondary", FRAME[d.aspect_ratio], d.aspect_ratio === "9:16" && "w-auto h-72")}>
        {d.kind === "image" && url && <img src={url} alt={d.title} loading="lazy" className="size-full object-cover" />}
        {d.kind === "video" && url && (
          <>
            <video src={url} muted playsInline preload="metadata" className="size-full object-cover" onMouseEnter={(e) => e.currentTarget.play().catch(() => {})} onMouseLeave={(e) => e.currentTarget.pause()} />
            <Play className="pointer-events-none absolute bottom-2 left-2 size-5 text-secondary-foreground" />
          </>
        )}
        {d.kind === "document" && <div className="flex size-full flex-col items-center justify-center gap-2 text-secondary-foreground"><FileText className="size-8" /><span className="text-xs font-bold">{d.file_type}</span></div>}
      </div>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button onClick={onClick} className={cn("rounded-full border px-3 py-1 text-xs font-semibold transition-colors", active ? "border-secondary bg-secondary text-secondary-foreground" : "hover:bg-muted")}>{children}</button>;
}

export function DeliverablesVault({ meId }: { meId: string }) {
  const [rows, setRows] = useState<DeliverableRow[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [aspect, setAspect] = useState<AspectRatio | "all">("all");
  const [type, setType] = useState<string>("all");
  const [campaign, setCampaign] = useState<string>("all");
  const [tag, setTag] = useState<string | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    supabase.from("deliverables").select("*").eq("client_id", meId).order("created_at", { ascending: false }).then(({ data }) => {
      setRows((data as DeliverableRow[] | null) ?? []);
      setLoaded(true);
    });
  }, [meId]);

  const types = useMemo(() => [...new Set(rows.map((r) => r.file_type))].sort(), [rows]);
  const campaigns = useMemo(() => [...new Set(rows.map((r) => r.campaign).filter((c): c is string => !!c))].sort(), [rows]);
  const tags = useMemo(() => [...new Set(rows.flatMap((r) => r.tags))].sort(), [rows]);
  const presentAspects = useMemo(() => new Set(rows.map((r) => r.aspect_ratio)), [rows]);

  const filtered = rows.filter((r) =>
    (aspect === "all" || r.aspect_ratio === aspect) &&
    (type === "all" || r.file_type === type) &&
    (campaign === "all" || r.campaign === campaign) &&
    (!tag || r.tags.includes(tag)) &&
    (!q.trim() || `${r.title} ${r.campaign ?? ""} ${r.tags.join(" ")}`.toLowerCase().includes(q.trim().toLowerCase())),
  );

  async function download(d: DeliverableRow) {
    try {
      const name = `${d.title}.${d.file_type.toLowerCase()}`;
      const url = await signedDeliverableUrl(d.path, name);
      window.location.assign(url);
      logActivity("deliverable_download", d.title);
    } catch (e) {
      toast.error((e as Error).message || "Download failed");
    }
  }

  return (
    <div className="mx-auto mt-6 max-w-6xl px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Client deliverables</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your campaign assets, ready to download. Links are private and expire after a few minutes.</p>
        </div>
        <div className="relative w-full max-w-xs">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input placeholder="Search assets" value={q} onChange={(e) => setQ(e.target.value)} className="pl-8" />
        </div>
      </div>

      {rows.length > 0 && (
        <div className="mt-5 grid gap-3 rounded-xl border bg-card p-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="w-20 text-xs font-semibold uppercase text-muted-foreground">Format</span>
            <Chip active={aspect === "all"} onClick={() => setAspect("all")}>All</Chip>
            {ASPECTS.filter((a) => presentAspects.has(a.value)).map((a) => <Chip key={a.value} active={aspect === a.value} onClick={() => setAspect(a.value)}>{a.label}</Chip>)}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="w-20 text-xs font-semibold uppercase text-muted-foreground">File type</span>
            <Chip active={type === "all"} onClick={() => setType("all")}>All</Chip>
            {types.map((t) => <Chip key={t} active={type === t} onClick={() => setType(t)}>{t}</Chip>)}
          </div>
          {campaigns.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="w-20 text-xs font-semibold uppercase text-muted-foreground">Campaign</span>
              <Chip active={campaign === "all"} onClick={() => setCampaign("all")}>All</Chip>
              {campaigns.map((c) => <Chip key={c} active={campaign === c} onClick={() => setCampaign(c)}>{c}</Chip>)}
            </div>
          )}
          {tags.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="w-20 text-xs font-semibold uppercase text-muted-foreground">Tags</span>
              {tags.map((t) => <Chip key={t} active={tag === t} onClick={() => setTag(tag === t ? null : t)}>#{t}</Chip>)}
            </div>
          )}
        </div>
      )}

      <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((d) => (
          <article key={d.id} className="overflow-hidden rounded-xl border bg-card">
            <Preview d={d} />
            <div className="grid gap-2 p-4">
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-sans text-base font-bold leading-tight">{d.title}</h2>
                <Badge variant="secondary" className="shrink-0">{d.file_type}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{[ASPECTS.find((a) => a.value === d.aspect_ratio)?.label, d.campaign, formatBytes(d.size_bytes)].filter(Boolean).join(" · ")}</p>
              {d.tags.length > 0 && <div className="flex flex-wrap gap-1">{d.tags.map((t) => <span key={t} className="text-[11px] text-muted-foreground">#{t}</span>)}</div>}
              <Button onClick={() => download(d)} className="mt-1"><Download />Download</Button>
            </div>
          </article>
        ))}
      </div>
      {loaded && !rows.length && <p className="mt-16 text-center text-muted-foreground">No deliverables yet. When the FLARE team shares files with you, they'll appear here.</p>}
      {rows.length > 0 && !filtered.length && <p className="mt-10 text-center text-muted-foreground">Nothing matches these filters.</p>}
    </div>
  );
}
