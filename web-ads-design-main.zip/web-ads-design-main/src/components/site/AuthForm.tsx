import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { logActivity } from "@/lib/log";

const G = () => (
  <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"/><path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/></svg>
);

export function AuthForm({ mode, onDone, title, hideLinks }: { mode: "login" | "register"; onDone?: () => void; title?: string; hideLinks?: boolean }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setBusy(false);
      if (error) { toast.error(error.message); return; }
      await logActivity("login", "Email sign-in");
      onDone?.();
    } else {
      const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { display_name: name } } });
      setBusy(false);
      if (error) { toast.error(error.message); return; }
      setSent(true);
    }
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.href });
    if (r.error) { toast.error("Google sign-in failed"); return; }
    if (r.redirected) return;
    await logActivity("login", "Google sign-in");
    onDone?.();
  }

  if (sent) return (
    <div className="w-full max-w-sm rounded-xl border bg-card p-8 text-center">
      <h1 className="text-2xl font-bold">Check your email</h1>
      <p className="mt-2 text-sm text-muted-foreground">We sent a confirmation link to {email}. Click it to activate your account.</p>
    </div>
  );

  return (
    <div className="w-full max-w-sm rounded-xl border bg-card p-8 shadow-sm">
      <h1 className="text-3xl font-bold">{title ?? (mode === "login" ? "Welcome back" : "Create account")}</h1>
      <form onSubmit={submit} className="mt-6 grid gap-4">
        {mode === "register" && (
          <div className="grid gap-1.5"><Label htmlFor="n">Name</Label><Input id="n" value={name} onChange={(e) => setName(e.target.value)} required /></div>
        )}
        <div className="grid gap-1.5"><Label htmlFor="e">Email</Label><Input id="e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
        <div className="grid gap-1.5"><Label htmlFor="p">Password</Label><Input id="p" type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} required /></div>
        <Button disabled={busy} type="submit">{busy ? "Please wait…" : mode === "login" ? "Log in" : "Sign up"}</Button>
      </form>
      <button type="button" onClick={google} className="mt-3 flex w-full items-center justify-center gap-2.5 rounded-md border px-3 py-2 text-sm font-medium" style={{ background: "#FFFFFF", borderColor: "#747775", color: "#1F1F1F" }}>
        <G /> Continue with Google
      </button>
      {!hideLinks && (
        <p className="mt-5 text-center text-sm text-muted-foreground">
          {mode === "login" ? <>No account? <Link to="/register" className="font-semibold text-foreground underline">Sign up</Link></> : <>Have an account? <Link to="/login" className="font-semibold text-foreground underline">Log in</Link></>}
        </p>
      )}
    </div>
  );
}
