import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { Download, FileText } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { type Block, type BlockProps, isVideo } from "@/lib/blocks";
import { downloadMedia, useMediaUrl } from "@/lib/media";
import { cn } from "@/lib/utils";

function useInView<T extends Element>() {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e?.isIntersecting && setInView(true), { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return { ref, inView };
}

const sizeHeading = { sm: "text-2xl md:text-3xl", md: "text-3xl md:text-5xl", lg: "text-4xl md:text-6xl", xl: "text-5xl md:text-8xl" };

function Section({ p, children, minH }: { p: BlockProps; children: ReactNode; minH?: string }) {
  const bgUrl = useMediaUrl(p.bg === "image" || p.bg === "video" ? p.bgMedia : undefined);
  const { ref, inView } = useInView<HTMLDivElement>();
  const style: CSSProperties = { color: p.textColor, ["--glow" as string]: p.glowColor ?? "#ff5a1f" };
  if (p.bg === "color") style.background = p.bgColor;
  if (p.bg === "gradient") style.background = `linear-gradient(${p.gradientAngle ?? 135}deg, ${p.gradientFrom}, ${p.gradientTo})`;
  if (p.bg === "image" && bgUrl) { style.backgroundImage = `url(${bgUrl})`; style.backgroundSize = "cover"; style.backgroundPosition = "center"; }
  const anim = p.animation && p.animation !== "none";
  return (
    <section id={p.anchor || undefined} className={cn("relative overflow-hidden", p.padded ? "px-6 py-20 md:px-16 md:py-28" : "")} style={{ ...style, minHeight: minH }}>
      {p.bg === "video" && bgUrl && <video src={bgUrl} autoPlay muted loop playsInline className="absolute inset-0 h-full w-full object-cover" />}
      {(p.bg === "image" || p.bg === "video") && <div className="absolute inset-0" style={{ background: `rgba(0,0,0,${p.overlay ?? 0.4})` }} />}
      {p.light && <div className="light-spot" />}
      <div ref={ref} className={cn("relative mx-auto max-w-6xl", anim ? `anim anim-${p.animation}` : "anim-none", inView && "in-view")} style={{ textAlign: p.align }}>
        {children}
      </div>
    </section>
  );
}

function Btn({ p, text, href }: { p: BlockProps; text?: string | undefined; href?: string | undefined }) {
  return (
    <a
      href={href || "#"}
      className={cn("inline-block font-semibold transition-transform hover:-translate-y-0.5", p.btnPadded ? "px-7 py-3.5" : "underline underline-offset-4", p.glow && "glow-box")}
      style={p.btnPadded ? { background: p.btnColor, color: p.btnTextColor, borderRadius: p.radius } : { color: p.btnColor }}
    >
      {text?.trim() || "Contact FLARE"}
    </a>
  );
}

function MediaItem({ path, className }: { path: string; className?: string }) {
  const url = useMediaUrl(path);
  if (!url) return <div className={cn("bg-black/10", className)} />;
  return isVideo(path)
    ? <video src={url} controls playsInline className={cn("w-full object-cover", className)} />
    : <img src={url} alt="" loading="lazy" className={cn("w-full object-cover", className)} />;
}

function FormBlock({ b, slug }: { b: Block; slug: string }) {
  const p = b.props;
  const fields = (p.fields ?? "").split(",").map((f) => f.trim()).filter(Boolean);
  const [busy, setBusy] = useState(false);
  return (
    <form
      className="mx-auto mt-8 grid max-w-xl gap-3 text-left"
      onSubmit={async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        const data = Object.fromEntries(fields.map((f) => [f, String(fd.get(f) ?? "").slice(0, 2000)]));
        setBusy(true);
        const { error } = await supabase.from("form_submissions").insert({ page_slug: slug, block_id: b.id, data });
        setBusy(false);
        if (error) toast.error("Could not send. Please try again.");
        else { toast.success("Thanks! We'll be in touch."); (e.target as HTMLFormElement).reset(); }
      }}
    >
      {fields.map((f) => (
        <label key={f} className="grid gap-1 text-sm font-medium">
          {f}
          {/message|note|details/i.test(f)
            ? <textarea name={f} required rows={4} className="rounded-md border border-current/20 bg-transparent px-3 py-2 outline-none focus:border-current" />
            : <input name={f} required type={/email/i.test(f) ? "email" : "text"} className="rounded-md border border-current/20 bg-transparent px-3 py-2 outline-none focus:border-current" />}
        </label>
      ))}
      <button disabled={busy} className={cn("mt-2 font-semibold", p.btnPadded ? "px-7 py-3.5" : "underline", p.glow && "glow-box")} style={p.btnPadded ? { background: p.btnColor, color: p.btnTextColor, borderRadius: p.radius } : { color: p.btnColor }}>
        {busy ? "Sending…" : p.buttonText?.trim() || "Send message"}
      </button>
    </form>
  );
}

const patternClass = {
  single: "grid grid-cols-1",
  grid: "grid grid-cols-2 md:grid-cols-3 gap-4",
  masonry: "columns-2 md:columns-3 gap-4 [&>*]:mb-4 [&>*]:break-inside-avoid",
  strip: "flex gap-4 overflow-x-auto snap-x [&>*]:snap-start [&>*]:min-w-[70%] md:[&>*]:min-w-[40%]",
  split: "grid md:grid-cols-2 gap-6",
};

export function BlockView({ block, slug }: { block: Block; slug: string }) {
  const p = block.props;
  const h = <h2 className={cn("font-display font-bold leading-[0.95]", sizeHeading[p.size ?? "md"], p.glow && "glow-text")}>{p.heading}</h2>;
  switch (block.type) {
    case "hero":
      return (
        <Section p={p} minH="80vh">
          <div className="flex min-h-[60vh] flex-col justify-center gap-6">
            <h1 className={cn("font-display font-extrabold leading-[0.9]", sizeHeading[p.size ?? "xl"], p.glow && "glow-text")}>{p.heading}</h1>
            {p.sub && <p className="max-w-2xl text-lg opacity-80 md:text-xl" style={{ marginInline: p.align === "center" ? "auto" : p.align === "right" ? "0 0 0 auto" : undefined }}>{p.sub}</p>}
            {p.buttonText && <div><Btn p={p} text={p.buttonText} href={p.buttonHref} /></div>}
          </div>
        </Section>
      );
    case "text":
      return <Section p={p}>{p.heading && h}{p.body && <p className="mt-5 whitespace-pre-line text-lg leading-relaxed opacity-85">{p.body}</p>}</Section>;
    case "button":
      return <Section p={p}><Btn p={p} text={p.text} href={p.href} /></Section>;
    case "form":
      return <Section p={p}>{p.heading && h}<FormBlock b={block} slug={slug} /></Section>;
    case "media":
      return (
        <Section p={p}>
          {p.heading && <div className="mb-8">{h}</div>}
          <div className={patternClass[p.pattern ?? "grid"]}>
            {(p.items ?? []).map((path, i) => (
              <MediaItem key={path + i} path={path} className={cn(p.pattern === "grid" && "aspect-square", p.pattern === "strip" && "aspect-video")} />
            ))}
          </div>
          {!p.items?.length && <p className="opacity-60">No pictures or videos yet.</p>}
        </Section>
      );
    case "download":
      return (
        <Section p={p}>
          {p.heading && <div className="mb-8">{h}</div>}
          <ul className="mx-auto grid max-w-xl gap-2 text-left">
            {(p.items ?? []).map((path) => (
              <li key={path} className="flex items-center justify-between gap-3 rounded-md border border-current/20 px-4 py-3">
                <span className="flex items-center gap-2 truncate"><FileText className="size-4 shrink-0" />{path.split("/").pop()}</span>
                <button onClick={() => downloadMedia(path).catch(() => toast.error("Download failed"))} className="flex items-center gap-1 text-sm font-semibold" style={{ color: p.btnColor }}>
                  <Download className="size-4" /> Download
                </button>
              </li>
            ))}
          </ul>
        </Section>
      );
    case "spacer":
      return <div style={{ height: p.height ?? 80, background: p.bg === "color" ? p.bgColor : undefined }} />;
  }
}
