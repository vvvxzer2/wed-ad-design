import { Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export function SiteNav() {
  const { user } = useAuth();
  const unread = useUnreadMessages(user?.id);
  return (
    <header className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-6 py-5 md:px-16">
      <Link to="/" className="font-display text-xl font-extrabold tracking-tight text-primary">FLARE®</Link>
      <nav className="flex items-center gap-4 text-sm font-semibold text-primary">
        {user ? (
          <>
            <Link to="/account/messages" className="relative flex items-center gap-1.5" aria-label={unread ? `Messages, ${unread} unread` : "Messages"}>
              <MessageCircle className="size-5" />
              {unread > 0 && (
                <span className="absolute -right-2 -top-2 flex min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground ring-2 ring-secondary">{unread}</span>
              )}
            </Link>
            <Link to="/account" className="rounded-full border border-primary/50 px-4 py-1.5">My account</Link>
          </>
        ) : (
          <>
            <Link to="/login">Log in</Link>
            <Link to="/register" className="rounded-full bg-primary px-4 py-1.5 text-primary-foreground">Join</Link>
          </>
        )}
      </nav>
    </header>
  );
}
