import type { SchemaHealth } from "@/lib/schema-check";

export function SetupIncomplete({ health }: { health: SchemaHealth }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-flame px-6 py-16 text-secondary-foreground">
      <div className="w-full max-w-xl rounded-2xl bg-background p-8 text-foreground shadow-glow">
        <p className="font-display text-sm font-bold uppercase tracking-widest text-primary">FLARE®</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold">The site is still being set up</h1>
        <p className="mt-3 text-muted-foreground">
          Some of the database isn't ready yet, so the home page can't load. Please check back in a moment.
        </p>
        {import.meta.env.DEV && (
          <div className="mt-6 space-y-4 rounded-xl border border-border bg-muted p-4 text-sm">
            <div>
              <p className="font-semibold">Missing tables ({health.missingTables.length})</p>
              <p className="mt-1 font-mono text-xs text-muted-foreground">{health.missingTables.join(", ")}</p>
            </div>
            <div>
              <p className="font-semibold">Migrations to apply</p>
              <ul className="mt-1 list-disc pl-5 font-mono text-xs text-muted-foreground">
                {health.pendingMigrations.map((m) => (
                  <li key={m}>{m}</li>
                ))}
              </ul>
            </div>
            <p className="text-xs text-muted-foreground">Checked {new Date(health.checkedAt).toLocaleTimeString()} · shown only in development</p>
          </div>
        )}
        <button
          type="button"
          onClick={() => location.reload()}
          className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Check again
        </button>
      </div>
    </main>
  );
}
