import { supabase } from "@/integrations/supabase/client";
import { nearestAspect } from "@/lib/chat-shared";

export const DELIVERABLES_BUCKET = "deliverables";

export type AspectRatio = "1:1" | "9:16" | "16:9" | "4:5" | "other";
export const ASPECTS: { value: AspectRatio; label: string }[] = [
  { value: "1:1", label: "1:1 Feed" },
  { value: "9:16", label: "9:16 Story / Reel" },
  { value: "16:9", label: "16:9 YouTube" },
  { value: "4:5", label: "4:5 Portrait" },
  { value: "other", label: "Other" },
];

export interface DeliverableRow {
  id: string;
  client_id: string;
  title: string;
  campaign: string | null;
  tags: string[];
  aspect_ratio: AspectRatio;
  file_type: string;
  kind: "image" | "video" | "document";
  path: string;
  size_bytes: number | null;
  notes: string | null;
  created_at: string;
}

export function fileKind(file: File): DeliverableRow["kind"] {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("video/") || /\.(mp4|webm|mov|m4v)$/i.test(file.name)) return "video";
  return "document";
}

export function fileTypeLabel(name: string) {
  return (name.split(".").pop() ?? "file").toUpperCase();
}

/** Read width/height of an image or video in the browser to guess its marketing aspect ratio. */
export function detectAspect(file: File): Promise<AspectRatio> {
  const kind = fileKind(file);
  if (kind === "document") return Promise.resolve("other");
  const url = URL.createObjectURL(file);
  return new Promise((resolve) => {
    const done = (w: number, h: number) => { URL.revokeObjectURL(url); resolve(nearestAspect(w, h)); };
    if (kind === "image") {
      const img = new Image();
      img.onload = () => done(img.naturalWidth, img.naturalHeight);
      img.onerror = () => done(0, 0);
      img.src = url;
    } else {
      const v = document.createElement("video");
      v.preload = "metadata";
      v.onloadedmetadata = () => done(v.videoWidth, v.videoHeight);
      v.onerror = () => done(0, 0);
      v.src = url;
    }
  });
}

/** Short-lived signed link (5 minutes) so files are never exposed through public URLs. */
export async function signedDeliverableUrl(path: string, downloadName?: string) {
  const { data, error } = await supabase.storage
    .from(DELIVERABLES_BUCKET)
    .createSignedUrl(path, 300, downloadName ? { download: downloadName } : undefined);
  if (error) throw error;
  return data.signedUrl;
}

export function formatBytes(n: number | null) {
  if (!n) return "";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${u[i]}`;
}
