export type BlockType = "hero" | "text" | "button" | "form" | "media" | "download" | "spacer";
export type BgKind = "none" | "color" | "gradient" | "image" | "video";
export type Animation = "none" | "fade-up" | "fade-in" | "zoom" | "slide-left" | "slide-right" | "float" | "pulse";
export type MediaPattern = "single" | "grid" | "masonry" | "strip" | "split";

export interface BlockProps {
  heading?: string;
  sub?: string;
  body?: string;
  text?: string;
  href?: string;
  buttonText?: string;
  buttonHref?: string;
  fields?: string;
  anchor?: string;
  padded?: boolean;
  btnPadded?: boolean;
  bg?: BgKind;
  bgColor?: string;
  gradientFrom?: string;
  gradientTo?: string;
  gradientAngle?: number;
  bgMedia?: string;
  overlay?: number;
  textColor?: string;
  btnColor?: string;
  btnTextColor?: string;
  align?: "left" | "center" | "right";
  animation?: Animation;
  glow?: boolean;
  glowColor?: string;
  light?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  radius?: number;
  items?: string[]; // media paths
  pattern?: MediaPattern;
  height?: number;
}

export interface Block {
  id: string;
  type: BlockType;
  props: BlockProps;
}

export const BLOCK_LABELS: Record<BlockType, string> = {
  hero: "Hero banner",
  text: "Text",
  button: "Button",
  form: "Form",
  media: "Pictures & videos",
  download: "Downloads",
  spacer: "Spacer",
};

export const newId = () => Math.random().toString(36).slice(2, 10);

export function defaultBlock(type: BlockType): Block {
  const base: BlockProps = {
    padded: true,
    bg: "color",
    bgColor: "#fff7ec",
    textColor: "#1a1208",
    align: "center",
    animation: "fade-up",
    glow: false,
    glowColor: "#ff5a1f",
    btnColor: "#ff5a1f",
    btnTextColor: "#1a1208",
    btnPadded: true,
    size: "md",
    radius: 8,
  };
  const by: Record<BlockType, BlockProps> = {
    hero: { heading: "Big bold headline", sub: "A short supporting line.", buttonText: "Get started", buttonHref: "#", size: "xl", bg: "gradient", gradientFrom: "#1a1208", gradientTo: "#ff5a1f", textColor: "#fff7ec", align: "left" },
    text: { heading: "Section title", body: "Write something persuasive here." },
    button: { text: "Click me", href: "#" },
    form: { heading: "Get in touch", fields: "Name,Email,Message", buttonText: "Send" },
    media: { heading: "Gallery", items: [], pattern: "grid" },
    download: { heading: "Downloads", items: [] },
    spacer: { height: 80, bg: "none" },
  };
  return { id: newId(), type, props: { ...base, ...by[type] } };
}

export function isVideo(path: string) {
  return /\.(mp4|webm|mov|m4v|ogg)$/i.test(path);
}
