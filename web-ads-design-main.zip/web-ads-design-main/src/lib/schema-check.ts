// Browser-safe description of the database tables the site needs, grouped by the
// migration that creates them, plus pure helpers to classify the probe results.

export const REQUIRED_TABLES = {
  "0000_flare_core_schema": ["profiles", "user_roles", "pages", "media", "form_submissions", "activity_log"],
  "0001_chat_dm_deliverables": ["chat_threads", "thread_participants", "chat_messages", "deliverables"],
} as const;

export type ProbeResult = { table: string; status: "ok" | "missing" | "error"; detail?: string | undefined };

export type SchemaHealth = {
  ok: boolean;
  /** True when at least one required table is missing (migrations not applied). */
  missingMigrations: boolean;
  missingTables: string[];
  /** Migration names that still need to run, in order. */
  pendingMigrations: string[];
  /** Tables whose probe failed for another reason (network, outage). */
  unreachable: string[];
  checkedAt: string;
};

/** PostgREST answers PGRST205 for a table it doesn't know; Postgres uses 42P01. */
export function isMissingTableError(code: string | undefined | null, message?: string | null): boolean {
  if (code === "PGRST205" || code === "42P01") return true;
  return !!message && /could not find the table|relation .* does not exist/i.test(message);
}

export function summarizeSchema(results: ProbeResult[], now = new Date()): SchemaHealth {
  const missingTables = results.filter((r) => r.status === "missing").map((r) => r.table);
  const unreachable = results.filter((r) => r.status === "error").map((r) => r.table);
  const pendingMigrations = Object.entries(REQUIRED_TABLES)
    .filter(([, tables]) => tables.some((t) => missingTables.includes(t)))
    .map(([name]) => name);
  return {
    ok: missingTables.length === 0 && unreachable.length === 0,
    missingMigrations: missingTables.length > 0,
    missingTables,
    pendingMigrations,
    unreachable,
    checkedAt: now.toISOString(),
  };
}

export function allRequiredTables(): string[] {
  return Object.values(REQUIRED_TABLES).flat();
}
