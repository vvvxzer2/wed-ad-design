// Server-only: FLARE AI strategist. Streams replies through Lovable AI Gateway,
// stores the finished reply in chat_messages, and can capture leads / hand over to a human.
import { createOpenAI } from "@ai-sdk/openai";
import { createUIMessageStream, createUIMessageStreamResponse, jsonSchema, stepCountIs, streamText, tool, type ModelMessage } from "ai";
import { ASSISTANT_INSTRUCTIONS } from "@/lib/assistant-knowledge";
import { MAX_MESSAGE_LENGTH, sanitizeVisitorMeta, wantsHuman } from "@/lib/chat-shared";
import { createLovableAiGatewayRunIdFetch, getLovableAiGatewayRunId, withLovableAiGatewayRunIdHeader } from "./run-id.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
const MODEL = "openai/gpt-6-astra";

const HANDOFF_TEXT =
  "Got it — I'm bringing in a strategist from the FLARE team. They'll reply right here in this chat. If you might step away, leave your email so we can follow up.";

function textStream(text: string) {
  const stream = createUIMessageStream({
    execute: ({ writer }) => {
      const id = crypto.randomUUID();
      writer.write({ type: "text-start", id });
      writer.write({ type: "text-delta", id, delta: text });
      writer.write({ type: "text-end", id });
    },
  });
  return createUIMessageStreamResponse({ stream });
}

function errorMessage(error: unknown): string {
  const status = (error as { statusCode?: number })?.statusCode;
  if (status === 402) return "The AI strategist is unavailable right now (AI credits used up). Switch to “Talk to a human” and the team will help.";
  if (status === 429) return "The AI strategist is busy. Please try again in a moment.";
  if (status === 403) return "The AI strategist can't answer this right now. Switch to “Talk to a human”.";
  return "The AI strategist hit a problem. Please try again, or switch to “Talk to a human”.";
}

export async function handleAssistantRequest(request: Request): Promise<Response> {
  let body: { token?: unknown; text?: unknown; meta?: unknown };
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text || text.length > MAX_MESSAGE_LENGTH) {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return Response.json({ error: "AI is not configured" }, { status: 500 });

  const { getAdmin, ensureVisitorThread, assertVisitorRate, assertAiBudget, requestCountry, requestIpHash, requireVisitor, RateLimitError, INVALID_SESSION } =
    await import("@/lib/visitor-chat.server");
  // Only a genuine server-issued visitor session can post here; the visitor id comes from its signature check.
  let visitorId: string;
  try {
    visitorId = await requireVisitor(body.token);
  } catch {
    return Response.json({ error: INVALID_SESSION }, { status: 401 });
  }
  const admin = await getAdmin();
  const [country, ipHash] = await Promise.all([requestCountry(), requestIpHash()]);
  const meta = sanitizeVisitorMeta(body.meta);
  let thread: Awaited<ReturnType<typeof ensureVisitorThread>>;
  try {
    thread = await ensureVisitorThread(admin, visitorId, {
      mode: "ai",
      ipHash,
      ...(meta ? { meta: { ...meta, ...(country ? { country } : {}) } } : {}),
    });
    await assertVisitorRate(admin, thread.id);
    if (!wantsHuman(text)) await assertAiBudget(admin, thread.id, ipHash);
  } catch (e) {
    if (e instanceof RateLimitError) return Response.json({ error: e.message }, { status: 429 });
    console.error("assistant setup failed", e);
    return Response.json({ error: "The AI strategist hit a problem. Please try again." }, { status: 500 });
  }
  await admin.from("chat_messages").insert({ thread_id: thread.id, sender_type: "visitor", content: text });

  // Deterministic escalation: the visitor asked for a person.
  if (wantsHuman(text)) {
    await admin.from("chat_threads").update({ mode: "human", status: "needs_human" }).eq("id", thread.id);
    await admin.from("chat_messages").insert({ thread_id: thread.id, sender_type: "ai", content: HANDOFF_TEXT });
    return textStream(HANDOFF_TEXT);
  }

  // Rebuild the conversation from the database (never trust client-sent history).
  const { data: rows } = await admin
    .from("chat_messages")
    .select("sender_type,content")
    .eq("thread_id", thread.id)
    .order("created_at", { ascending: false })
    .limit(20);
  const history: ModelMessage[] = (rows ?? [])
    .reverse()
    .filter((r) => r.content)
    .map((r) =>
      r.sender_type === "visitor"
        ? { role: "user" as const, content: r.content }
        : { role: "assistant" as const, content: r.sender_type === "admin" ? `[FLARE team member]: ${r.content}` : r.content },
    );

  const threadId = thread.id;
  const tools = {
    capture_lead: tool({
      description: "Save the visitor as a sales lead once you have at least their name and email. Use for quote, proposal or meeting requests.",
      inputSchema: jsonSchema<{ name: string; email: string; budget: string | null; service: string | null; timeline: string | null; details: string | null; wants_meeting: boolean }>({
        type: "object",
        additionalProperties: false,
        required: ["name", "email", "budget", "service", "timeline", "details", "wants_meeting"],
        properties: {
          name: { type: "string" },
          email: { type: "string" },
          budget: { type: ["string", "null"] },
          service: { type: ["string", "null"] },
          timeline: { type: ["string", "null"] },
          details: { type: ["string", "null"] },
          wants_meeting: { type: "boolean" },
        },
      }),
      execute: async (lead) => {
        const email = lead.email.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { saved: false, reason: "Email looks invalid — ask the visitor to double-check it." };
        const data: Record<string, string> = { Name: lead.name, Email: email, Source: "AI Strategist chat" };
        if (lead.budget) data["Budget"] = lead.budget;
        if (lead.service) data["Service"] = lead.service;
        if (lead.timeline) data["Timeline"] = lead.timeline;
        if (lead.details) data["Message"] = lead.details;
        if (lead.wants_meeting) data["Meeting"] = "Requested a discovery call";
        const { error } = await admin.from("form_submissions").insert({ page_slug: "ai-assistant", block_id: threadId, data });
        if (error) return { saved: false, reason: "Could not save right now." };
        await admin
          .from("chat_threads")
          .update({ visitor_name: lead.name, visitor_email: email, ...(lead.wants_meeting ? { status: "needs_human" } : {}) })
          .eq("id", threadId);
        return { saved: true };
      },
    }),
    request_human: tool({
      description: "Hand this conversation to a human FLARE team member.",
      inputSchema: jsonSchema<{ reason: string }>({
        type: "object",
        additionalProperties: false,
        required: ["reason"],
        properties: { reason: { type: "string" } },
      }),
      execute: async ({ reason }) => {
        await admin.from("chat_threads").update({ mode: "human", status: "needs_human", meta: { ...((thread.meta as object) ?? {}), handoff_reason: reason.slice(0, 300) } }).eq("id", threadId);
        return { handed_over: true };
      },
    }),
  };

  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });

  const result = streamText({
    model: provider.responses(MODEL),
    instructions: ASSISTANT_INSTRUCTIONS,
    messages: history,
    tools,
    stopWhen: stepCountIs(4),
    maxOutputTokens: 1500,
    abortSignal: request.signal,
    providerOptions: {
      openai: {
        store: false,
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        include: ["reasoning.encrypted_content"],
      },
    },
    onFinish: async ({ steps }) => {
      const full = steps.map((s) => s.text).filter(Boolean).join("\n\n").trim();
      if (full) await admin.from("chat_messages").insert({ thread_id: threadId, sender_type: "ai", content: full });
    },
    onError: ({ error }) => {
      console.error("assistant stream error", error);
    },
  });

  return withLovableAiGatewayRunIdHeader(
    result.toUIMessageStreamResponse({ sendReasoning: true, onError: errorMessage }),
    runIdFetch,
  );
}
