// Browser-only chat helpers (call from effects / event handlers).
import { describeUserAgent, visitorIdFromToken, type VisitorMeta } from "@/lib/chat-shared";

const TOKEN_KEY = "flare_visitor_token";
const LEGACY_ID_KEY = "flare_visitor_id";

/** The server-signed visitor session saved in this browser, if it looks valid. */
export function readVisitorToken(): string | null {
  localStorage.removeItem(LEGACY_ID_KEY); // unsigned ids from older versions are no longer accepted
  const t = localStorage.getItem(TOKEN_KEY);
  return t && visitorIdFromToken(t) ? t : null;
}

export function saveVisitorToken(token: string | null) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

export const isInvalidSessionError = (e: unknown) => /VISITOR_SESSION_INVALID/.test(String((e as Error)?.message ?? e));

export function collectVisitorMeta(): VisitorMeta {
  return {
    ...describeUserAgent(navigator.userAgent),
    language: navigator.language,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    page: location.pathname,
    ...(document.referrer ? { referrer: document.referrer.slice(0, 300) } : {}),
  };
}

let audioCtx: AudioContext | null = null;
/** Short two-tone chime + vibration for incoming messages. */
export function notifyIncoming(sound: boolean) {
  if (!sound) return;
  try {
    audioCtx ??= new AudioContext();
    const ctx = audioCtx;
    [660, 880].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      osc.type = "sine";
      const t = ctx.currentTime + i * 0.12;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.15, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.2);
    });
  } catch {
    /* audio blocked */
  }
  try {
    navigator.vibrate?.(80);
  } catch {
    /* unsupported */
  }
}

export function timeLabel(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
