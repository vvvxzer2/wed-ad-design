// Server-only helpers for anonymous visitor chat. Visitors never touch the chat
// tables directly: every read/write goes through here after verifying their
// server-signed visitor session token (the visitor id inside it is never caller-chosen).
import { isUuid, type VisitorMeta } from "@/lib/chat-shared";

const enc = new TextEncoder();
let keyPromise: Promise<CryptoKey> | null = null;

function signingKey(): Promise<CryptoKey> {
  const secret = process.env["VISITOR_TOKEN_SECRET"];
  if (!secret) throw new Error("Visitor chat is not configured");
  keyPromise ??= crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
  return keyPromise;
}

function toB64Url(buf: ArrayBuffer): string {
  let bin = "";
  for (const b of new Uint8Array(buf)) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromB64Url(s: string): Uint8Array<ArrayBuffer> | null {
  try {
    const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/"));
    return Uint8Array.from(bin, (c) => c.charCodeAt(0));
  } catch {
    return null;
  }
}

/** Issue a fresh visitor identity, signed so it can't be forged or chosen by the caller. */
export async function mintVisitorToken(): Promise<{ token: string; visitorId: string }> {
  const visitorId = crypto.randomUUID();
  const sig = await crypto.subtle.sign("HMAC", await signingKey(), enc.encode(`visitor:${visitorId}`));
  return { token: `v1.${visitorId}.${toB64Url(sig)}`, visitorId };
}

export const INVALID_SESSION = "VISITOR_SESSION_INVALID";

/** Returns the visitor id for a genuine server-issued token, otherwise throws. */
export async function requireVisitor(token: unknown): Promise<string> {
  if (typeof token !== "string" || token.length > 200) throw new Error(INVALID_SESSION);
  const [v, id, sig] = token.split(".");
  const bytes = sig ? fromB64Url(sig) : null;
  if (v !== "v1" || !isUuid(id) || !bytes) throw new Error(INVALID_SESSION);
  const ok = await crypto.subtle.verify("HMAC", await signingKey(), bytes, enc.encode(`visitor:${id}`));
  if (!ok) throw new Error(INVALID_SESSION);
  return id;
}

/** Opaque per-network fingerprint used only for abuse limits (raw IPs are never stored). */
export async function requestIpHash(): Promise<string | undefined> {
  try {
    const { getRequestHeader } = await import("@tanstack/react-start/server");
    const ip = getRequestHeader("cf-connecting-ip") ?? getRequestHeader("x-forwarded-for")?.split(",")[0]?.trim();
    if (!ip) return undefined;
    const sig = await crypto.subtle.sign("HMAC", await signingKey(), enc.encode(`ip:${ip}`));
    return toB64Url(sig).slice(0, 22);
  } catch {
    return undefined;
  }
}

type Admin = (typeof import("@/integrations/supabase/client.server"))["supabaseAdmin"];

export async function getAdmin(): Promise<Admin> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export async function findVisitorThread(admin: Admin, visitorId: string) {
  const { data, error } = await admin
    .from("chat_threads")
    .select("id,status,mode,visitor_name,visitor_email,meta")
    .eq("visitor_id", visitorId)
    .eq("type", "visitor")
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export async function ensureVisitorThread(
  admin: Admin,
  visitorId: string,
  opts: { mode?: "ai" | "human"; meta?: VisitorMeta; name?: string | null; email?: string | null; ipHash?: string | undefined } = {},
) {
  const existing = await findVisitorThread(admin, visitorId);
  if (existing) {
    const patch: Record<string, unknown> = {};
    if (opts.mode && opts.mode !== existing.mode) patch["mode"] = opts.mode;
    if (opts.name) patch["visitor_name"] = opts.name;
    if (opts.email) patch["visitor_email"] = opts.email;
    if (opts.meta) patch["meta"] = { ...((existing.meta as object) ?? {}), ...opts.meta };
    if (Object.keys(patch).length) {
      const { data, error } = await admin.from("chat_threads").update(patch as never).eq("id", existing.id)
        .select("id,status,mode,visitor_name,visitor_email,meta").single();
      if (error) throw new Error(error.message);
      return data;
    }
    return existing;
  }
  // Abuse guard: a single network can only open a few new conversations per hour.
  if (opts.ipHash) {
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count } = await admin
      .from("chat_threads")
      .select("id", { count: "exact", head: true })
      .eq("type", "visitor")
      .eq("meta->>ip_hash", opts.ipHash)
      .gte("created_at", since);
    if ((count ?? 0) >= MAX_NEW_THREADS_PER_NETWORK_HOUR) throw new RateLimitError("Too many new chats from your network. Please try again later.");
  }
  const { data, error } = await admin
    .from("chat_threads")
    .insert({
      type: "visitor",
      visitor_id: visitorId,
      mode: opts.mode ?? "human",
      meta: { ...(opts.meta ?? {}), ...(opts.ipHash ? { ip_hash: opts.ipHash } : {}) } as never,
      visitor_name: opts.name ?? null,
      visitor_email: opts.email ?? null,
    })
    .select("id,status,mode,visitor_name,visitor_email,meta")
    .single();
  if (error) throw new Error(error.message);
  return data;
}

export class RateLimitError extends Error {}

const MAX_NEW_THREADS_PER_NETWORK_HOUR = 5;
const MAX_AI_REPLIES_PER_THREAD_HOUR = 20;
const MAX_AI_REPLIES_PER_NETWORK_HOUR = 30;
const MAX_AI_REPLIES_SITE_HOUR = 300;
const MAX_AI_REPLIES_SITE_DAY = 1500;

const AI_LIMIT_MESSAGE = "You've reached the AI strategist's limit for now. Switch to “Talk to a human” and the team will reply.";
const AI_BUSY_MESSAGE = "The AI strategist is very busy right now. Switch to “Talk to a human” and the team will reply.";

/**
 * Cost guard for the paid AI. Every reply must fit inside four budgets:
 * per conversation, per network (hashed IP, across all its conversations),
 * site-wide per hour and site-wide per day, so total AI spend stays bounded
 * even when someone scripts many anonymous sessions.
 */
export async function assertAiBudget(admin: Admin, threadId: string, ipHash?: string) {
  const hourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const aiCount = () => admin.from("chat_messages").select("id", { count: "exact", head: true }).eq("sender_type", "ai");
  const [perThread, siteHour, siteDay] = await Promise.all([
    aiCount().eq("thread_id", threadId).gte("created_at", hourAgo),
    aiCount().gte("created_at", hourAgo),
    aiCount().gte("created_at", dayAgo),
  ]);
  if ((perThread.count ?? 0) >= MAX_AI_REPLIES_PER_THREAD_HOUR) throw new RateLimitError(AI_LIMIT_MESSAGE);
  if ((siteHour.count ?? 0) >= MAX_AI_REPLIES_SITE_HOUR || (siteDay.count ?? 0) >= MAX_AI_REPLIES_SITE_DAY) throw new RateLimitError(AI_BUSY_MESSAGE);

  if (ipHash) {
    const { data: threads } = await admin
      .from("chat_threads")
      .select("id")
      .eq("type", "visitor")
      .eq("meta->>ip_hash", ipHash)
      .gte("last_message_at", hourAgo)
      .limit(50);
    const ids = (threads ?? []).map((t) => t.id);
    if (!ids.includes(threadId)) ids.push(threadId);
    const { count } = await aiCount().in("thread_id", ids).gte("created_at", hourAgo);
    if ((count ?? 0) >= MAX_AI_REPLIES_PER_NETWORK_HOUR) throw new RateLimitError(AI_LIMIT_MESSAGE);
  }
}

/** Simple abuse guard: at most 40 visitor messages per thread per hour. */
export async function assertVisitorRate(admin: Admin, threadId: string) {
  const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const { count } = await admin
    .from("chat_messages")
    .select("id", { count: "exact", head: true })
    .eq("thread_id", threadId)
    .eq("sender_type", "visitor")
    .gte("created_at", since);
  if ((count ?? 0) >= 40) throw new RateLimitError("You're sending messages too quickly. Please wait a little and try again.");
}

export async function requestCountry(): Promise<string | undefined> {
  try {
    const { getRequestHeader } = await import("@tanstack/react-start/server");
    return getRequestHeader("cf-ipcountry") ?? undefined;
  } catch {
    return undefined;
  }
}
