import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Block } from "@/lib/blocks";

export const pageQuery = (slug: string) =>
  queryOptions({
    queryKey: ["page", slug],
    queryFn: async () => {
      const { data, error } = await supabase.from("pages").select("*").eq("slug", slug).maybeSingle();
      // If page content can't be read (e.g. the database is still being set up), render an
      // empty page with a notice instead of crashing the whole site.
      if (error) {
        console.error("Could not load page content", error);
        return { title: "Page", blocks: [] as Block[], unavailable: true };
      }
      return { title: data?.title ?? "Page", blocks: ((data?.blocks as unknown) as Block[]) ?? [], unavailable: false };
    },
  });
