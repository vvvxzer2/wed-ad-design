import { supabase } from "@/integrations/supabase/client";

export async function logActivity(action: string, details?: string) {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return;
  await supabase.from("activity_log").insert({ user_id: data.user.id, email: data.user.email ?? null, action, details: details ?? null });
}
