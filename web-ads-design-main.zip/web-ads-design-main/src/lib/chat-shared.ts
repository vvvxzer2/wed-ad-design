// Shared (browser + server) chat helpers. No secrets, no server-only imports.

export type SenderType = "visitor" | "admin" | "member" | "ai";
export type ThreadStatus = "open" | "needs_human" | "closed" | "archived";
export type ThreadMode = "ai" | "human";

export interface ChatMessageRow {
  id: string;
  thread_id: string;
  sender_type: SenderType;
  sender_id: string | null;
  content: string;
  attachment_path: string | null;
  attachment_name: string | null;
  attachment_type: string | null;
  is_read: boolean;
  created_at: string;
}

export interface VisitorMeta {
  device?: string | undefined;
  browser?: string | undefined;
  os?: string | undefined;
  language?: string | undefined;
  timezone?: string | undefined;
  page?: string | undefined;
  referrer?: string | undefined;
  country?: string | undefined;
}

export const MAX_MESSAGE_LENGTH = 2000;

const META_LIMITS: Record<Exclude<keyof VisitorMeta, "country">, number> = {
  device: 40, browser: 40, os: 40, language: 40, timezone: 80, page: 300, referrer: 300,
};

/** Keep only the known, length-limited visitor details from untrusted input. */
export function sanitizeVisitorMeta(input: unknown): VisitorMeta | undefined {
  if (!input || typeof input !== "object") return undefined;
  const out: VisitorMeta = {};
  for (const [key, max] of Object.entries(META_LIMITS) as [keyof typeof META_LIMITS, number][]) {
    const v = (input as Record<string, unknown>)[key];
    if (typeof v === "string" && v.trim()) out[key] = v.trim().slice(0, max);
  }
  return Object.keys(out).length ? out : undefined;
}

/** Visitor session tokens look like `v1.<uuid>.<signature>`; returns the uuid part (not verified). */
export function visitorIdFromToken(token: string): string | null {
  const [v, id, sig] = token.split(".");
  return v === "v1" && isUuid(id) && !!sig ? id : null;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const isUuid = (v: unknown): v is string => typeof v === "string" && UUID_RE.test(v);

/** Visitor typed something that clearly asks for a real person. */
export function wantsHuman(text: string): boolean {
  return /\b(agent|human|real person|a person|someone real|operator|representative|talk to (?:the )?team|speak to (?:the )?team)\b/i.test(text);
}

/** Rough device/browser/os summary from a user agent string. */
export function describeUserAgent(ua: string): Pick<VisitorMeta, "device" | "browser" | "os"> {
  const device = /iPad|Tablet/i.test(ua) ? "Tablet" : /Mobi|Android|iPhone/i.test(ua) ? "Mobile" : "Desktop";
  const browser = /Edg\//.test(ua) ? "Edge" : /OPR\//.test(ua) ? "Opera" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "Browser";
  const os = /Windows/.test(ua) ? "Windows" : /iPhone|iPad|iOS/.test(ua) ? "iOS" : /Mac OS X/.test(ua) ? "macOS" : /Android/.test(ua) ? "Android" : /Linux/.test(ua) ? "Linux" : "Unknown";
  return { device, browser, os };
}

/** Pick the closest marketing aspect ratio for a width/height pair. */
export function nearestAspect(width: number, height: number): "1:1" | "9:16" | "16:9" | "4:5" | "other" {
  if (!width || !height) return "other";
  const r = width / height;
  const options: [("1:1" | "9:16" | "16:9" | "4:5"), number][] = [["1:1", 1], ["9:16", 9 / 16], ["16:9", 16 / 9], ["4:5", 4 / 5]];
  let best: (typeof options)[number] | undefined;
  for (const o of options) if (!best || Math.abs(o[1] - r) < Math.abs(best[1] - r)) best = o;
  return best && Math.abs(best[1] - r) / best[1] <= 0.04 ? best[0] : "other";
}
