import { createServerFn } from "@tanstack/react-start";
import { allRequiredTables, isMissingTableError, summarizeSchema, type ProbeResult, type SchemaHealth } from "@/lib/schema-check";

// A healthy result is reused briefly so every page view doesn't re-probe the database.
// Failures are never cached, so the site recovers as soon as migrations land.
let healthyUntil = 0;
let lastHealthy: SchemaHealth | null = null;
const HEALTHY_TTL_MS = 60_000;

async function probe(base: string, key: string, table: string): Promise<ProbeResult> {
  try {
    const res = await fetch(`${base}/rest/v1/${table}?select=*&limit=0`, {
      headers: { apikey: key, Accept: "application/json" },
    });
    if (res.ok) return { table, status: "ok" };
    const body = (await res.json().catch(() => ({}))) as { code?: string; message?: string };
    if (isMissingTableError(body.code, body.message)) return { table, status: "missing", detail: body.message };
    // Permission errors still prove the table exists.
    if (res.status === 401 || res.status === 403 || body.code === "42501") return { table, status: "ok" };
    return { table, status: "error", detail: body.message ?? `HTTP ${res.status}` };
  } catch (e) {
    return { table, status: "error", detail: e instanceof Error ? e.message : String(e) };
  }
}

export const checkDatabaseSetup = createServerFn({ method: "GET" }).handler(async (): Promise<SchemaHealth> => {
  if (lastHealthy && Date.now() < healthyUntil) return lastHealthy;

  const base = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
  if (!base || !key) {
    console.error("[startup-check] SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY are not set; cannot verify database tables.");
    return summarizeSchema(allRequiredTables().map((table) => ({ table, status: "error", detail: "not configured" })));
  }

  const results = await Promise.all(allRequiredTables().map((t) => probe(base, key, t)));
  const health = summarizeSchema(results);

  if (health.missingMigrations) {
    console.error(
      `[startup-check] Database setup incomplete. Missing tables: ${health.missingTables.join(", ")}. ` +
        `Apply pending migrations: ${health.pendingMigrations.join(", ")}.`,
    );
  } else if (health.unreachable.length) {
    console.warn(
      `[startup-check] Could not verify tables: ${results
        .filter((r) => r.status === "error")
        .map((r) => `${r.table} (${r.detail})`)
        .join(", ")}`,
    );
  } else {
    lastHealthy = health;
    healthyUntil = Date.now() + HEALTHY_TTL_MS;
  }
  return health;
});
