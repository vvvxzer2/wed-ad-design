import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { MAX_MESSAGE_LENGTH, sanitizeVisitorMeta } from "@/lib/chat-shared";

// Visitors are identified only by a server-signed session token, never by an id they pick.
const token = z.string().min(1).max(200);

/** Issue a new anonymous visitor session (signed token kept in the visitor's browser). */
export const startVisitorSession = createServerFn({ method: "POST" }).handler(async () => {
  const { mintVisitorToken } = await import("@/lib/visitor-chat.server");
  const { token: t } = await mintVisitorToken();
  return { token: t };
});

/** Load the visitor's own thread and messages. */
export const getVisitorChat = createServerFn({ method: "POST" })
  .validator((d: unknown) => z.object({ token }).parse(d))
  .handler(async ({ data }) => {
    const { getAdmin, findVisitorThread, requireVisitor } = await import("@/lib/visitor-chat.server");
    const visitorId = await requireVisitor(data.token);
    const admin = await getAdmin();
    const thread = await findVisitorThread(admin, visitorId);
    if (!thread) return { thread: null, messages: [] as VisitorMessage[] };
    const { data: rows, error } = await admin
      .from("chat_messages")
      .select("id,sender_type,content,created_at")
      .eq("thread_id", thread.id)
      .order("created_at", { ascending: true })
      .limit(300);
    if (error) throw new Error("Could not load messages");
    return {
      thread: { id: thread.id, status: thread.status, mode: thread.mode, visitor_name: thread.visitor_name, visitor_email: thread.visitor_email },
      messages: (rows ?? []) as VisitorMessage[],
    };
  });

export type VisitorMessage = { id: string; sender_type: "visitor" | "admin" | "ai" | "member"; content: string; created_at: string };

/** Visitor sends a message to the human team. */
export const sendVisitorMessage = createServerFn({ method: "POST" })
  .validator((d: unknown) =>
    z.object({ token, content: z.string().trim().min(1).max(MAX_MESSAGE_LENGTH), meta: z.unknown().optional() }).parse(d),
  )
  .handler(async ({ data }) => {
    const { getAdmin, ensureVisitorThread, assertVisitorRate, requestCountry, requestIpHash, requireVisitor } = await import("@/lib/visitor-chat.server");
    const visitorId = await requireVisitor(data.token);
    const admin = await getAdmin();
    const [country, ipHash] = await Promise.all([requestCountry(), requestIpHash()]);
    const meta = sanitizeVisitorMeta(data.meta);
    const thread = await ensureVisitorThread(admin, visitorId, {
      mode: "human",
      ipHash,
      ...(meta ? { meta: { ...meta, ...(country ? { country } : {}) } } : {}),
    });
    await assertVisitorRate(admin, thread.id);
    const { error } = await admin.from("chat_messages").insert({ thread_id: thread.id, sender_type: "visitor", content: data.content });
    if (error) throw new Error("Message not sent");
    return { ok: true, threadId: thread.id };
  });

/** Visitor leaves optional name/email so the team can follow up offline. */
export const updateVisitorInfo = createServerFn({ method: "POST" })
  .validator((d: unknown) =>
    z.object({
      token,
      name: z.string().trim().max(100).optional(),
      email: z.string().trim().email().max(200).optional().or(z.literal("")),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { getAdmin, ensureVisitorThread, requestIpHash, requireVisitor } = await import("@/lib/visitor-chat.server");
    const visitorId = await requireVisitor(data.token);
    const admin = await getAdmin();
    await ensureVisitorThread(admin, visitorId, { name: data.name || null, email: data.email || null, ipHash: await requestIpHash() });
    return { ok: true };
  });

/** Switch between the AI strategist and a human. Asking for a human pings the Studio inbox. */
export const setVisitorMode = createServerFn({ method: "POST" })
  .validator((d: unknown) => z.object({ token, mode: z.enum(["ai", "human"]) }).parse(d))
  .handler(async ({ data }) => {
    const { getAdmin, findVisitorThread, requireVisitor } = await import("@/lib/visitor-chat.server");
    const visitorId = await requireVisitor(data.token);
    const admin = await getAdmin();
    const thread = await findVisitorThread(admin, visitorId);
    if (!thread) return { ok: true };
    const patch: { mode: "ai" | "human"; status?: string } = { mode: data.mode };
    if (data.mode === "human" && thread.mode === "ai") patch.status = "needs_human";
    await admin.from("chat_threads").update(patch).eq("id", thread.id);
    return { ok: true };
  });
