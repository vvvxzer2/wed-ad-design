-- 1. Membership checks only answer about the signed-in caller, and anonymous callers can't run them.
create or replace function public.is_thread_participant(_thread_id uuid, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(_user_id = auth.uid(), false)
     and exists (select 1 from public.thread_participants where thread_id = _thread_id and user_id = _user_id)
$$;
revoke execute on function public.is_thread_participant(uuid, uuid) from public, anon;
grant execute on function public.is_thread_participant(uuid, uuid) to authenticated, service_role;

-- 2. Member directory no longer reveals email addresses; an exact email still finds someone.
create or replace function public.search_members(_q text)
returns table(id uuid, display_name text, email text, avatar_url text)
language sql stable security definer set search_path = public as $$
  select p.id, p.display_name, null::text as email, p.avatar_url
  from public.profiles p
  where auth.uid() is not null and p.id <> auth.uid()
    and (coalesce(btrim(_q), '') = ''
         or p.display_name ilike '%' || replace(replace(replace(btrim(_q), '\', '\\'), '%', '\%'), '_', '\_') || '%'
         or lower(p.email) = lower(btrim(_q)))
  order by p.display_name nulls last
  limit 20
$$;
revoke execute on function public.search_members(text) from public, anon;
grant execute on function public.search_members(text) to authenticated, service_role;

-- 3. Signing up never grants admin. Admin is assigned explicitly by an existing admin (or the project owner).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)));
  insert into public.user_roles (user_id, role) values (new.id, 'member');
  return new;
end; $$;

-- 4. The media library list is for the Studio only.
drop policy if exists "anyone reads media" on public.media;
revoke select on public.media from anon;
create policy "admin reads media" on public.media for select to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- 5. Media files: admins read all; the public only gets files used on a live page;
--    profile photos are visible to their owner and people they share a conversation with.
drop policy if exists "media read all" on storage.objects;
create policy "media admin read" on storage.objects for select to authenticated
  using (bucket_id = 'media' and public.has_role(auth.uid(), 'admin'));
create policy "media published read" on storage.objects for select to anon, authenticated
  using (
    bucket_id = 'media'
    and coalesce((storage.foldername(name))[1], '') <> 'avatars'
    and exists (
      select 1 from public.pages p
      where position(('"' || name || '"') in (p.blocks::text || p.theme::text)) > 0
    )
  );
create policy "media avatar read" on storage.objects for select to authenticated
  using (
    bucket_id = 'media'
    and (storage.foldername(name))[1] = 'avatars'
    and (
      (storage.foldername(name))[2] = (select auth.uid()::text)
      or exists (
        select 1
        from public.thread_participants me
        join public.thread_participants other on other.thread_id = me.thread_id
        where me.user_id = (select auth.uid())
          and other.user_id::text = (storage.foldername(name))[2]
      )
    )
  );

-- 6. Public form submissions must target a real form on a real page, with a bounded payload.
drop policy if exists "anyone submits" on public.form_submissions;
create policy "visitors submit page forms" on public.form_submissions for insert to anon, authenticated
  with check (
    block_id is not null
    and length(block_id) <= 64
    and jsonb_typeof(data) = 'object'
    and pg_column_size(data) <= 16384
    and exists (
      select 1 from public.pages p
      where p.slug = page_slug
        and jsonb_path_exists(p.blocks, '$.** ? (@.type == "form" && @.id == $b)', jsonb_build_object('b', block_id))
    )
  );