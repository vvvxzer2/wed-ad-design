-- 1. Role checks only answer about the signed-in caller, and anonymous callers can't run them.
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(_user_id = auth.uid(), false)
     and exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
revoke execute on function public.has_role(uuid, app_role) from public, anon;
grant execute on function public.has_role(uuid, app_role) to authenticated, service_role;

-- 2. Member search no longer lists the whole member base. It returns:
--    people you already have a conversation with (matched by name),
--    the agency team (admins, matched by name),
--    and anyone else only on an exact full name or exact email.
create or replace function public.search_members(_q text)
returns table(id uuid, display_name text, email text, avatar_url text)
language sql stable security definer set search_path = public as $$
  with q as (select btrim(coalesce(_q, '')) as v)
  select p.id, p.display_name, null::text as email, p.avatar_url
  from public.profiles p, q
  where auth.uid() is not null and p.id <> auth.uid()
    and length(q.v) >= 2
    and (
      lower(p.email) = lower(q.v)
      or lower(btrim(p.display_name)) = lower(q.v)
      or (
        p.display_name ilike '%' || replace(replace(replace(q.v, '\', '\\'), '%', '\%'), '_', '\_') || '%'
        and (
          exists (select 1 from public.user_roles r where r.user_id = p.id and r.role = 'admin')
          or exists (
            select 1 from public.thread_participants me
            join public.thread_participants o on o.thread_id = me.thread_id
            where me.user_id = auth.uid() and o.user_id = p.id
          )
        )
      )
    )
  order by p.display_name nulls last
  limit 10
$$;
revoke execute on function public.search_members(text) from public, anon;
grant execute on function public.search_members(text) to authenticated, service_role;