create type public.app_role as enum ('admin','member');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  avatar_url text,
  bio text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select, insert, delete on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "own profile read" on public.profiles for select to authenticated using (auth.uid() = id or public.has_role(auth.uid(),'admin'));
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id or public.has_role(auth.uid(),'admin'));
create policy "admin delete profile" on public.profiles for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create policy "read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(),'admin'));
create policy "admin add roles" on public.user_roles for insert to authenticated with check (public.has_role(auth.uid(),'admin'));
create policy "admin remove roles" on public.user_roles for delete to authenticated using (public.has_role(auth.uid(),'admin') and user_id <> auth.uid());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)));
  insert into public.user_roles (user_id, role) values (new.id, 'member');
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.pages (
  slug text primary key,
  title text not null default 'Page',
  blocks jsonb not null default '[]'::jsonb,
  theme jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid
);
grant select on public.pages to anon;
grant select, insert, update, delete on public.pages to authenticated;
grant all on public.pages to service_role;
alter table public.pages enable row level security;
create policy "anyone reads pages" on public.pages for select to anon, authenticated using (true);
create policy "admin writes pages" on public.pages for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.media (
  id uuid primary key default gen_random_uuid(),
  path text not null,
  name text not null,
  kind text not null,
  url text not null,
  created_at timestamptz not null default now()
);
grant select on public.media to anon;
grant select, insert, delete on public.media to authenticated;
grant all on public.media to service_role;
alter table public.media enable row level security;
create policy "anyone reads media" on public.media for select to anon, authenticated using (true);
create policy "admin adds media" on public.media for insert to authenticated with check (public.has_role(auth.uid(),'admin'));
create policy "admin deletes media" on public.media for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.form_submissions (
  id uuid primary key default gen_random_uuid(),
  page_slug text not null,
  block_id text,
  data jsonb not null,
  created_at timestamptz not null default now()
);
grant insert on public.form_submissions to anon;
grant select, insert, delete on public.form_submissions to authenticated;
grant all on public.form_submissions to service_role;
alter table public.form_submissions enable row level security;
create policy "anyone submits" on public.form_submissions for insert to anon, authenticated with check (true);
create policy "admin reads submissions" on public.form_submissions for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin deletes submissions" on public.form_submissions for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.activity_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  email text,
  action text not null,
  details text,
  created_at timestamptz not null default now()
);
grant select, insert on public.activity_log to authenticated;
grant all on public.activity_log to service_role;
alter table public.activity_log enable row level security;
create policy "log own" on public.activity_log for insert to authenticated with check (auth.uid() = user_id);
create policy "read logs" on public.activity_log for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(),'admin'));

create policy "media read all" on storage.objects for select to anon, authenticated using (bucket_id = 'media');
create policy "media admin insert" on storage.objects for insert to authenticated with check (bucket_id = 'media' and public.has_role(auth.uid(),'admin'));
create policy "media admin delete" on storage.objects for delete to authenticated using (bucket_id = 'media' and public.has_role(auth.uid(),'admin'));
create policy "avatar upload own" on storage.objects for insert to authenticated with check (bucket_id = 'media' and (storage.foldername(name))[1] = 'avatars' and (storage.foldername(name))[2] = auth.uid()::text);

insert into public.pages (slug, title, blocks) values ('home','Home', '[
 {"id":"b1","type":"hero","props":{"heading":"Ads that refuse to be ignored.","sub":"We design campaigns, motion and media that move people — and metrics.","buttonText":"Start a project","buttonHref":"#contact","padded":true,"btnPadded":true,"bg":"gradient","bgColor":"#120f0a","gradientFrom":"#1a1208","gradientTo":"#ff5a1f","textColor":"#fff7ec","align":"left","animation":"fade-up","glow":true,"size":"xl"}},
 {"id":"b2","type":"text","props":{"heading":"Strategy. Creative. Motion.","body":"From the first insight to the final frame, our studio builds brand stories engineered for attention across social, video and display.","padded":true,"bg":"color","bgColor":"#fff7ec","textColor":"#1a1208","align":"center","animation":"fade-in","size":"md"}},
 {"id":"b3","type":"button","props":{"text":"See our work","href":"#","padded":true,"btnPadded":true,"bg":"color","bgColor":"#fff7ec","btnColor":"#ff5a1f","btnTextColor":"#1a1208","align":"center","animation":"zoom","glow":false}},
 {"id":"b4","type":"form","props":{"heading":"Tell us about your campaign","fields":"Name,Email,Budget,Message","buttonText":"Send","padded":true,"btnPadded":true,"bg":"color","bgColor":"#1a1208","textColor":"#fff7ec","btnColor":"#ff5a1f","btnTextColor":"#1a1208","align":"center","animation":"slide-left","anchor":"contact"}}
]'::jsonb);