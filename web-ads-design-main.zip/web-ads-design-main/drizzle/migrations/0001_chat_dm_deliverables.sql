-- ===== Chat threads (visitor live chat, member DMs, AI) =====
create table public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('visitor','member','ai')),
  visitor_id text unique,
  visitor_name text,
  visitor_email text,
  status text not null default 'open' check (status in ('open','needs_human','closed','archived')),
  mode text not null default 'human' check (mode in ('ai','human')),
  meta jsonb not null default '{}'::jsonb,
  last_message_at timestamptz not null default now(),
  last_message_preview text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.chat_threads to authenticated;
grant all on public.chat_threads to service_role;
alter table public.chat_threads enable row level security;

create table public.thread_participants (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  last_read_at timestamptz not null default now(),
  is_muted boolean not null default false,
  unique (thread_id, user_id)
);
create index thread_participants_user_idx on public.thread_participants(user_id);
grant select on public.thread_participants to authenticated;
grant update (last_read_at, is_muted) on public.thread_participants to authenticated;
grant all on public.thread_participants to service_role;
alter table public.thread_participants enable row level security;

create table public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  sender_type text not null check (sender_type in ('visitor','admin','member','ai')),
  sender_id uuid,
  content text not null default '',
  attachment_path text,
  attachment_name text,
  attachment_type text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index chat_messages_thread_idx on public.chat_messages(thread_id, created_at);
grant select, insert, update, delete on public.chat_messages to authenticated;
grant all on public.chat_messages to service_role;
alter table public.chat_messages enable row level security;

create or replace function public.is_thread_participant(_thread_id uuid, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.thread_participants where thread_id = _thread_id and user_id = _user_id)
$$;

create or replace function public.can_access_thread_folder(_folder text, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select case
    when _folder ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then public.is_thread_participant(_folder::uuid, _user_id) or public.has_role(_user_id, 'admin')
    else false end
$$;

-- threads
create policy "threads read" on public.chat_threads for select to authenticated
  using (public.has_role(auth.uid(),'admin') or public.is_thread_participant(id, auth.uid()));
create policy "threads admin insert" on public.chat_threads for insert to authenticated
  with check (public.has_role(auth.uid(),'admin'));
create policy "threads admin update" on public.chat_threads for update to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "threads admin delete" on public.chat_threads for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

-- participants
create policy "participants read" on public.thread_participants for select to authenticated
  using (user_id = auth.uid() or public.is_thread_participant(thread_id, auth.uid()) or public.has_role(auth.uid(),'admin'));
create policy "participants update own" on public.thread_participants for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- messages
create policy "messages read" on public.chat_messages for select to authenticated
  using (public.has_role(auth.uid(),'admin') or public.is_thread_participant(thread_id, auth.uid()));
create policy "messages insert" on public.chat_messages for insert to authenticated
  with check (
    sender_id = auth.uid() and (
      (sender_type = 'admin' and public.has_role(auth.uid(),'admin'))
      or (sender_type = 'member' and public.is_thread_participant(thread_id, auth.uid()))
    )
  );
create policy "messages admin update" on public.chat_messages for update to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "messages admin delete" on public.chat_messages for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

-- Keep thread summary fresh + ring the visitor's doorbell (data-free) on new messages.
create or replace function public.on_chat_message_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare t public.chat_threads;
begin
  update public.chat_threads
    set last_message_at = new.created_at,
        last_message_preview = left(coalesce(nullif(new.content,''), '📎 ' || coalesce(new.attachment_name,'Attachment')), 140),
        updated_at = now(),
        status = case when status in ('closed','archived') and new.sender_type = 'visitor' then 'open' else status end
    where id = new.thread_id
    returning * into t;
  if t.type = 'visitor' and t.visitor_id is not null then
    begin
      perform realtime.send(jsonb_build_object('thread_id', t.id), 'new_message', 'visitor:' || t.visitor_id, false);
    exception when others then null;
    end;
  end if;
  return new;
end; $$;
create trigger chat_message_inserted after insert on public.chat_messages
  for each row execute function public.on_chat_message_insert();

-- Start (or reuse) a 1:1 member conversation.
create or replace function public.start_direct_thread(_other uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); tid uuid;
begin
  if me is null then raise exception 'Not signed in'; end if;
  if _other = me then raise exception 'Cannot message yourself'; end if;
  if not exists (select 1 from public.profiles where id = _other) then raise exception 'Member not found'; end if;
  select p1.thread_id into tid
    from public.thread_participants p1
    join public.thread_participants p2 on p2.thread_id = p1.thread_id and p2.user_id = _other
    join public.chat_threads t on t.id = p1.thread_id and t.type = 'member'
    where p1.user_id = me
      and (select count(*) from public.thread_participants x where x.thread_id = p1.thread_id) = 2
    limit 1;
  if tid is not null then return tid; end if;
  insert into public.chat_threads (type) values ('member') returning id into tid;
  insert into public.thread_participants (thread_id, user_id) values (tid, me), (tid, _other);
  return tid;
end; $$;
revoke execute on function public.start_direct_thread(uuid) from anon, public;
grant execute on function public.start_direct_thread(uuid) to authenticated;

-- Member directory search (signed-in members only).
create or replace function public.search_members(_q text)
returns table (id uuid, display_name text, email text, avatar_url text)
language sql stable security definer set search_path = public as $$
  select p.id, p.display_name, p.email, p.avatar_url
  from public.profiles p
  where auth.uid() is not null and p.id <> auth.uid()
    and (coalesce(_q,'') = '' or p.display_name ilike '%' || _q || '%' or p.email ilike '%' || _q || '%')
  order by p.display_name nulls last
  limit 20
$$;
revoke execute on function public.search_members(text) from anon, public;
grant execute on function public.search_members(text) to authenticated;

-- My member conversations with the other person's info and unread counts.
create or replace function public.my_member_threads()
returns table (thread_id uuid, other_id uuid, other_name text, other_email text, other_avatar text,
               other_last_read_at timestamptz, last_message_at timestamptz, last_message_preview text, unread bigint)
language sql stable security definer set search_path = public as $$
  select t.id, o.user_id, pr.display_name, pr.email, pr.avatar_url, o.last_read_at,
         t.last_message_at, t.last_message_preview,
         (select count(*) from public.chat_messages m
           where m.thread_id = t.id and m.created_at > me.last_read_at and m.sender_id is distinct from auth.uid())
  from public.thread_participants me
  join public.chat_threads t on t.id = me.thread_id and t.type = 'member'
  join public.thread_participants o on o.thread_id = t.id and o.user_id <> me.user_id
  left join public.profiles pr on pr.id = o.user_id
  where me.user_id = auth.uid()
  order by t.last_message_at desc
$$;
revoke execute on function public.my_member_threads() from anon, public;
grant execute on function public.my_member_threads() to authenticated;

create or replace function public.my_unread_total()
returns bigint language sql stable security definer set search_path = public as $$
  select coalesce(count(*),0) from public.chat_messages m
  join public.thread_participants me on me.thread_id = m.thread_id and me.user_id = auth.uid()
  join public.chat_threads t on t.id = m.thread_id and t.type = 'member'
  where m.created_at > me.last_read_at and m.sender_id is distinct from auth.uid()
$$;
revoke execute on function public.my_unread_total() from anon, public;
grant execute on function public.my_unread_total() to authenticated;

alter publication supabase_realtime add table public.chat_messages;
alter publication supabase_realtime add table public.chat_threads;
alter publication supabase_realtime add table public.thread_participants;

-- Chat attachments: <thread_id>/<user_id>/<file>
create policy "attachments read participants" on storage.objects for select to authenticated
  using (bucket_id = 'attachments' and public.can_access_thread_folder((storage.foldername(name))[1], auth.uid()));
create policy "attachments upload participants" on storage.objects for insert to authenticated
  with check (bucket_id = 'attachments'
    and public.can_access_thread_folder((storage.foldername(name))[1], auth.uid())
    and (storage.foldername(name))[2] = auth.uid()::text);

-- ===== Client deliverables =====
create table public.deliverables (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  campaign text,
  tags text[] not null default '{}',
  aspect_ratio text not null default 'other' check (aspect_ratio in ('1:1','9:16','16:9','4:5','other')),
  file_type text not null,
  kind text not null check (kind in ('image','video','document')),
  path text not null,
  size_bytes bigint,
  notes text,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index deliverables_client_idx on public.deliverables(client_id, created_at desc);
grant select, insert, update, delete on public.deliverables to authenticated;
grant all on public.deliverables to service_role;
alter table public.deliverables enable row level security;
create policy "deliverables read own" on public.deliverables for select to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "deliverables admin insert" on public.deliverables for insert to authenticated
  with check (public.has_role(auth.uid(),'admin'));
create policy "deliverables admin update" on public.deliverables for update to authenticated
  using (public.has_role(auth.uid(),'admin'));
create policy "deliverables admin delete" on public.deliverables for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

-- Deliverable files: <client_id>/<file>
create policy "deliverable files read" on storage.objects for select to authenticated
  using (bucket_id = 'deliverables' and ((storage.foldername(name))[1] = auth.uid()::text or public.has_role(auth.uid(),'admin')));
create policy "deliverable files admin insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'deliverables' and public.has_role(auth.uid(),'admin'));
create policy "deliverable files admin delete" on storage.objects for delete to authenticated
  using (bucket_id = 'deliverables' and public.has_role(auth.uid(),'admin'));