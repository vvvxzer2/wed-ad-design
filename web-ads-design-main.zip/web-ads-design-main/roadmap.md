# Roadmap
- [x] Login, register, logout, account management, activity log
- [x] Hidden admin studio with drag-and-drop page editor, media uploads, submissions, accounts
- [x] Moved site, Studio and database into this project
- [x] Visitor ↔ team live chat (floating widget + Studio inbox, quick replies, close/archive, presence, sound)
- [x] Member ↔ member messages (directory search, read receipts, typing, attachments, unread badge)
- [x] AI Strategist (streaming, lead capture into submissions, hand-over to a human)
- [x] Client deliverables vault (Studio upload, filters by format/type/campaign/tag, secure downloads)
- [ ] Existing records from the old project (page edits, media files, users, submissions) — waiting on export from the user
- [x] AI Strategist pricing in Swedish kronor ("from" prices, excl. VAT)
