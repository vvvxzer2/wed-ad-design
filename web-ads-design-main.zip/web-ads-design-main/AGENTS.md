<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- Page content is stored as JSON blocks in `pages.blocks` (types in src/lib/blocks.ts) and rendered by `BlockView`; the editor and public site share that renderer so the preview matches the live site.
- Media lives in a private `media` storage bucket and is shown through signed URLs (workspace blocks public buckets).
- Admin rights come only from `user_roles` via `has_role`; account deletion goes through the `deleteAccount` server function. Signing up only ever grants `member`; admin is granted explicitly (existing admin in Studio, or the agent via SQL on the owner's request). Why: auto-admin on first signup let any stranger take over an empty site.
- Anonymous visitors never touch chat tables directly: their reads/writes go through `src/lib/visitor-chat.functions.ts` (server, service role) keyed by a server-signed visitor token (`v1.<uuid>.<hmac>`, VISITOR_TOKEN_SECRET) minted by `startVisitorSession` and kept in localStorage, so the visitor id is never caller-chosen; AI replies are capped per thread, per network (hashed IP, across its threads), site-wide per hour and per day in visitor-chat.server.ts; new messages ring a data-free Realtime broadcast on `visitor:<id>` so the widget refetches. Why: RLS can't safely identify anonymous visitors.
- One `chat_threads` table serves visitor chat (`type='visitor'`, `mode` ai|human, `status` incl. needs_human) and member DMs (`type='member'` + `thread_participants`); member access is via `is_thread_participant` and the `start_direct_thread` / `my_member_threads` / `search_members` security-definer functions. `search_members` only matches existing contacts and admins by partial name, everyone else by exact full name or email; `has_role`/`is_thread_participant` only answer for `auth.uid()`. Why: members must not be able to browse the member base or probe other users' roles.
- The AI strategist streams from the public route `/api/public/assistant` (server-only logic in src/lib/ai/assistant.server.ts) and rebuilds history from the database, never from the client; agency facts live in src/lib/assistant-knowledge.ts.
- Chat attachments live in the private `attachments` bucket under `<thread_id>/<user_id>/`, deliverables in the private `deliverables` bucket under `<client_id>/`; both are only served through short-lived signed URLs.
- Studio presence channel `studio-presence` drives the "Team online" indicator in the visitor widget.
- The home route loader runs `checkDatabaseSetup` (src/lib/schema-check.functions.ts) before reading page content; required tables and the migration that creates each live in `REQUIRED_TABLES` (src/lib/schema-check.ts). Add new tables there when a migration adds one. Why: a missing migration shows a clear setup notice instead of a 500.
- Media bucket reads: admins read all; anon/authenticated read only files referenced in some `pages.blocks`/`theme`; avatars (`avatars/<uid>/`) only by their owner and people sharing a thread. Why: unused library files and profile photos stay private.
