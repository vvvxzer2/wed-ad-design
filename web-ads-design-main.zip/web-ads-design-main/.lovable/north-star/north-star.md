<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Brands get ad creative and campaigns from the studio that win them customers.

## Metric

Deliverables downloaded by clients each month
